<html lang="en">
<head>
<title>Buy Organic Seeds, Dry Fruits &amp; Nuts from Soultatva</title>

<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0, minimal-ui" />


<link rel="icon" type="image/png" href="favicon.png">
<link rel="shortcut icon" href="favicon.ico">


<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Nunito:ital,wght@0,200;0,300;0,400;0,600;0,700;0,800;0,900;1,200;1,300;1,400;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">



<link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">

	
<link href="css/common-text.css" rel="stylesheet" type="text/css" />
<link href="css/common-layout.css" rel="stylesheet" type="text/css" />

<link rel="stylesheet" type="text/css" href="css/resrponsive.css">



</head>

<body class="logingbg">
	
	
	<div class="loader"><span></span></div>
	
    
    <a href="javascript:void(0);" id="Arrowfix" style="display: none;"><span></span></a>
    
	
	
	
	
	
	
	<!--Contain Wrapper-->
	
	<div class="loginmainbox registerbox">
		<div class="loginlogo"><a href="index.php"><img src="images/soultatva-logo1.png" alt="" ></a></div>
		<h3>Create Account</h3>
		<div class="formbox1">
			<label>Your name</label>
			<input type="text"  name="name" id="name" value="" required>
		</div>
		<div class="formbox1">
			<label>Email</label>
			<input type="text"  name="email" id="email" value="" required>
		</div>
		<div class="formbox1">
			<label>Mobile phone number</label>
			<input type="text"  name="mobile" id="mobile" value="" required>
		</div>
		<div class="formbox1">
			<label>Password</label>
			<input type="password"  name="password" id="password" value="" required>
		</div>
		<p>Passwords must be at least 6 characters.</p>
		<p>We will send you a text to verify your phone. Message and Data rates may apply.</p>
		<button type="submit" id="submit" name="submit" class="button">Continue</button>
		<p>By continuing, you agree to Soultatva <a href="#">Conditions of Use</a> and <a href="#">Privacy Notice</a>.</p>
		<p class="tac">Already have an account? <a href="signin.php">Sign in</a></p>
		
	</div>
	
	<!--END-->
	
	
	
 

<script type="text/javascript" src="js/jquery-3.3.1.min.js"></script>
<script type="text/javascript" src="js/ajax-1.9.0.min.js"></script>

<script type="text/javascript">
	$(document).ready(function(){
		$(window).scroll(function(){
			if ($(this).scrollTop() > 50) {
				$('#Arrowfix').fadeIn();
			} else {
				$('#Arrowfix').fadeOut();
			}
		});
		$('#Arrowfix').click(function(){
			$("html, body").animate({ scrollTop: 0 }, 400);
			return false;
		});
	});
</script>
	
<script type="text/javascript">
	$(window).load(function() {
		$(".loader").fadeOut("slow");
	})
</script>	

</body>
</html>
