<html lang="en">
<head>
<title>Buy Organic Seeds, Dry Fruits &amp; Nuts from Soultatva</title>

<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0, minimal-ui" />


<link rel="icon" type="image/png" href="favicon.png">
<link rel="shortcut icon" href="favicon.ico">


<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Nunito:ital,wght@0,200;0,300;0,400;0,600;0,700;0,800;0,900;1,200;1,300;1,400;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">



<link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">



<link href="css/jquery.bxslider.css" rel="stylesheet" type="text/css" />
	
<link href="css/common-text.css" rel="stylesheet" type="text/css" />
<link href="css/common-layout.css" rel="stylesheet" type="text/css" />
<link href="css/menu.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="css/resrponsive.css">
<link rel="stylesheet" href="css/jquery.fancybox.min.css" type="text/css" media="screen" />
<link href="css/jquery.bxslider.css" rel="stylesheet" type="text/css" />


</head>

<body>
	
	
	<div class="loader"><span></span></div>
    
    <a href="javascript:void(0);" id="Arrowfix" style="display: none;"><span></span></a>
    
	
	
	
	<!--TOPMAIN-->
	<div class="topmain">
		<div class="topmainleft">
			<select name="langues" id="langues">
			  <option value="English">English</option>
			  <option value="Hindi">Hindi</option>
			  <option value="Gujarati">Gujarati</option>
			  <option value="Marathi">Marathi</option>
			</select>
		</div>
		<div class="topmainright">
			<a href="mywhishlist.php">My Wishlist</a> <span>|</span>
			<a href="signin.php">Sign in</a> <span>|</span>
			<a href="register.php">Register</a> <span>|</span>
			<a href="store.php">Store Locator</a> <span>|</span>
			<a href="blog.php">Blog</a>
		</div>
	</div>
	<!--TOPMAIN-->
    
	
	
	<!--TOPMAIN Wrapper-->
	<div class="topmainwrapper">
		<div class="topmaincol1"><a href="index.php"><img src="images/soultatva-logo1.png" alt="" ></a></div>
		<div class="topmaincol2">
			<input type="text" placeholder="Search for products" ><button>Search</button>
		</div>
		<div class="topmaincol3">
			<div class="group clearboth">
				<h6><a href="tel:Call 1300 000 XXX">Call 1300 000 XXX</a></h6>
				<h5><a href="#">Cart <i class="fa fa-shopping-cart" aria-hidden="true"></i> <span>0</span></a></h5>
			</div>
		</div>
	</div>
	<!--TOPMAIN-->
	
	
	<!--Menu-->
	
	<div class="menubg">
		<nav>
			<a href="#"><i class="fa fa-bars fa-2x"></i></a>
			<ul>
				<li><a href="index.php">Home</a></li>
				<li><a href="about.php">About US</a> <i class="fa fa-caret-down"></i>
					<ul>
						<li><a href="our-story.php">Our Story</a></li>
						<li><a href="eternallypure.php">Eternally Pure</a></li>
						<li><a href="process.php">process</a></li>
					</ul>
				</li>
				<li><a href="products.php">Products</a> <i class="fa fa-caret-down"></i>
					<ul>
						<li><a href="products.php">Products</a></li>
						<li><a href="seed.php">Seed <i class="fa fa-caret-right"></i></a>
							<ul>
								<li><a href="products.php">Seed Name 1</a></li>
								<li><a href="products.php">Seed Name 2</a></li>
								<li><a href="products.php">Seed Name 3</a></li>
							</ul>
						</li>
						<li><a href="nut.php">Nut <i class="fa fa-caret-right"></i></a>
							<ul>
								<li><a href="products.php">Nut Name 1</a></li>
								<li><a href="products.php">Nut Name 2</a></li>
								<li><a href="products.php">Nut Name 3</a></li>
							</ul>
						</li>
						<li><a href="combos.php">Combos <i class="fa fa-caret-right"></i></a>
							<ul>
								<li><a href="products.php">Combos Name 1</a></li>
								<li><a href="products.php">Combos Name 2</a></li>
								<li><a href="products.php">Combos Name 3</a></li>
							</ul>
						</li>
					</ul>
				</li>
				<li><a href="our-pillars.php">Our Pillars</a></li>
				<li><a href="recipes">Recipes</a></li>
				<li><a href="blog.php">Blog</a></li>
				<li><a href="contact-us.php">Contact us</a></li>
			</ul>
		</nav>
	</div>
	
	<!--END-->
	
	
	<!--Contain Wrapper-->
	
	<div class="containwrapper">
		
		<div class="bredcum">
			<h1>Seed</h1>
			<a href="index.php">Home</a> <i class="fa fa-angle-double-right"></i> <a href="products.php">Products</a> <i class="fa fa-angle-double-right"></i> <span>Sunflower Seeds Roasted Salted</span>
		</div>
		
		<div class="group clearboth">
			<div class="productdetailleft">
				
				<div class="group clearboth">
					<ul class="nobullet productsslider">
						<li><img src="images/product-detail1.jpg" alt="" ></li>
						<li><img src="images/product-detail1.jpg" alt="" ></li>
						<li><img src="images/product-detail1.jpg" alt="" ></li>
						<li><img src="images/product-detail1.jpg" alt="" ></li>
						<li><img src="images/product-detail1.jpg" alt="" ></li>
					</ul>
					<div class="bx-pager">
						  <a data-slide-index="0" href=""><img src="images/product-detail1.jpg" /></a>
						  <a data-slide-index="1" href=""><img src="images/product-detail1.jpg" /></a>
						  <a data-slide-index="2" href=""><img src="images/product-detail1.jpg" /></a>
						<a data-slide-index="3" href=""><img src="images/product-detail1.jpg" /></a>
						<a data-slide-index="4" href=""><img src="images/product-detail1.jpg" /></a>
						</div>
				</div>
				
				
				

				
				<div class="btn1"><a href="#"><i class="fa fa-shopping-cart" aria-hidden="true"></i> Add</a></div>
				
			</div>
			<div class="productdetailright">
			  <h3>Flax Seeds Roasted Salted(Pack Of 12) <span>Flax seeds for good gut health</span></h3>
			  <div class="detailtopstar"><span>4.5 <i class="fa fa-star"></i></span> 9 Ratings & 7 Reviews</div>
			  <hr>
			  <div class="maindetailprice"><span>₹420</span><i>₹599</i></div>
			  <div class="maindetailquantity">
					<a href="#"><span>20</span>GM</a>
					<a href="#"><span>200</span>GM</a>
					<a href="#"><span>500</span>GM</a>
					<a href="#"><span>1</span>KG</a>
					<a href="#"><span>2</span>KG</a>
				</div>
			  <div class="detailsbtn">
					<div class="btn1"><a href="#">Buy Now <i class="fa fa-shopping-cart" aria-hidden="true"></i></a></div>
					<a href="#"><img src="images/amazon.png" alt="" ></a>
				</div>
				
				<div class="shopshare">
					<ul class="bullet1">
						<li>Shop secure, Free Returns</li>
					</ul>
					<div class="btn1"><a href="#">Add to whislist</a> <a href="#">Add to Compare</a></div>
					<h6>Share  <a href="https://www.facebook.com/Soultatva" target="_blank"><i class="fab fa-facebook"></i></a>
                        <a href="https://www.linkedin.com/showcase/soul-tatva" target="_blank"><i class="fab fa-linkedin"></i></a>
                        <a href="https://twitter.com/SoulTatva" target="_blank"><i class="fab fa-twitter"></i></a>
                        <a href="https://www.instagram.com/soultatva/" target="_blank"><i class="fab fa-instagram"></i></a>
					</h6>
				</div>
				
				<table class="table1">
				  <tbody>
					<tr>
					  <td><span>Allergen Information</span></td>
					  <td>Allergen-Free, Gluten Free, Preservative-Free, BPA-Free</td>
					</tr>
					<tr>
					  <td><span>Specialty</span></td>
					  <td>100% Organic, No Preservative, GMO Free, Gluten Free, Vegan</td>
					</tr>
					<tr>
					  <td><span>Diet Type</span></td>
					  <td>Halal, Kosher, Vegan</td>
					</tr>
					<tr>
					  <td colspan="2">
						  <span>Flax Seeds Roasted Salted</span>
						  <ul class="bullet1">
						  	<li>100% Organic,Gluten-free, Vegan-friendly, No chemical preservatives, No Chemical additives, Not genetically engineered and Freshly Packed.</li>
							<li>An ideal addition to vegetarian, vegan, whole food, paleo, ketogenic, and gluten-free diets.</li>
							<li>Can Enjoy it with : DIY granola, overnight oatmeal, add them as your salad topping, sprinkle them to your cereal, add them to your smoothies, bread topping, bake it with your granola bars.</li>
							<li>Seeds arrive ready in easy to use, BPA-free packaging.</li>
							<li>Farm to Table, Product of India.</li>
						  </ul>
						</td>
				    </tr>
				  </tbody>
				</table>

				
				
				
				
			</div>
		</div>
		
		
		
		
		<div class="tablemain">
			<div class="tab">
				<button class="tablinks " onClick="openCity(event, 'description')">Description</button>
				<button class="tablinks active" onClick="openCity(event, 'reviews')">Reviews</button>
				<button class="tablinks" onClick="openCity(event, 'shipping')">Shipping Information</button>
			</div>
			<div id="description" class="tabcontent">
				<p>Soul Tatva Flax seeds make for a healthy addition to your diet and blend seamlessly into everyday meals- be it vegetables, breads, salads, or desserts. Flax seeds pave your way to a healthy heart, and a tastier meal.</p>
			</div>
			<div id="reviews" class="tabcontent" style="display:block;">
				<div class="group clearboth">
					<div class="reviewsleft">
						<div class="starimg"><img src="images/star-icon1.png" alt="" > <img src="images/star-icon1.png" alt="" > <img src="images/star-icon1.png" alt="" > <img src="images/star-icon1.png" alt="" > <img src="images/star-icon1.png" alt="" ></div>
						<div class="startime">4.3 out of 5</div>
						<div class="starmain">
							<p><span>5 star</span> <i></i> <span>61%</span></p>
							<p><span>4 star</span> <i></i> <span>5%</span></p>
							<p><span>3 star</span> <i></i> <span>2%</span></p>
							<p><span>2 star</span> <i></i> <span>1%</span></p>
							<p><span>1 star</span> <i></i> <span>0%</span></p>
						</div>
						<h6>
							<span>Review this product</span>
							Share your thoughts with other customers
						</h6>
						<div class="btn1"><a href="#">Write a product review</a></div>
						
					</div>
					<div class="reviewsright">
						<div class="reviewsdetail">
							<h5><img src="images/img1.jpg" alt="" > <span>Kamal Masuriya</span></h5>
							<div class="starimg1"><img src="images/star-icon1.png" alt="" > <img src="images/star-icon1.png" alt="" > <img src="images/star-icon1.png" alt="" > <img src="images/star-icon1.png" alt="" > <img src="images/star-icon2.png" alt="" ></div>
							<h6>Verified Purchase</h6>
							<p>Dhara is one of the most trusted brands in India, All products manufactured by Dhara is of fine quality. This particular product is no different in terms of quality. Price is also on the lower side if you compare it with orhers</p>
						</div>
						<div class="reviewsdetail">
							<h5><img src="images/img1.jpg" alt="" > <span>Kamal Masuriya</span></h5>
							<div class="starimg1"><img src="images/star-icon1.png" alt="" > <img src="images/star-icon1.png" alt="" > <img src="images/star-icon1.png" alt="" > <img src="images/star-icon1.png" alt="" > <img src="images/star-icon1.png" alt="" ></div>
							<h6>Verified Purchase</h6>
							<p>Dhara is one of the most trusted brands in India, All products manufactured by Dhara is of fine quality. This particular product is no different in terms of quality. Price is also on the lower side if you compare it with orhers</p>
						</div>
						<div class="reviewsdetail">
							<h5><img src="images/img1.jpg" alt="" > <span>Kamal Masuriya</span></h5>
							<div class="starimg1"><img src="images/star-icon1.png" alt="" > <img src="images/star-icon1.png" alt="" > <img src="images/star-icon1.png" alt="" > <img src="images/star-icon1.png" alt="" > <img src="images/star-icon2.png" alt="" ></div>
							<h6>Verified Purchase</h6>
							<p>Dhara is one of the most trusted brands in India, All products manufactured by Dhara is of fine quality. This particular product is no different in terms of quality. Price is also on the lower side if you compare it with orhers</p>
						</div>
						<div class="reviewsdetail">
							<h5><img src="images/img1.jpg" alt="" > <span>Kamal Masuriya</span></h5>
							<div class="starimg1"><img src="images/star-icon1.png" alt="" > <img src="images/star-icon1.png" alt="" > <img src="images/star-icon1.png" alt="" > <img src="images/star-icon1.png" alt="" > <img src="images/star-icon1.png" alt="" ></div>
							<h6>Verified Purchase</h6>
							<p>Dhara is one of the most trusted brands in India, All products manufactured by Dhara is of fine quality. This particular product is no different in terms of quality. Price is also on the lower side if you compare it with orhers</p>
						</div>
						
						<div><strong><a href="#">See all reviews <i class="fa fa-angle-right"></i></a></strong></div>
					</div>
				</div>
				
				
				
			</div>
			<div id="shipping" class="tabcontent">
				Shipping Information
			</div>
		</div>
		
		
		
	</div>
	
	<!--END-->
	
	
	<!--Contain Wrapper-->
	
	<div class="bg1">
		<div class="containwrapper">
			<h3>Releted Products</h3>
			<ul class="nobullet assetsslide">
				<li>
					<div class="conbox2">
						<a href="products-detail.php">
							<img src="images/tranding1.jpg" alt="" >
						</a>
						<div class="conbox2con trandingheight">
							<h6>Sunflower Seeds Roasted Salted</h6>
							<h5><span>₹420</span><i>₹599</i></h5>
							<div class="btn1"><a href="products-detail.php">Add to cart</a></div>
						</div>
					</div>
				</li>
				<li>
					<div class="conbox2">
						<a href="products-detail.php">
							<img src="images/tranding1.jpg" alt="" >
						</a>
						<div class="conbox2con trandingheight">
							<h6>Sunflower Seeds Roasted Salted</h6>
							<h5><span>₹420</span><i>₹599</i></h5>
							<div class="btn1"><a href="products-detail.php">Add to cart</a></div>
						</div>
					</div>
				</li>
				<li>
					<div class="conbox2">
						<a href="products-detail.php">
							<img src="images/tranding1.jpg" alt="" >
						</a>
						<div class="conbox2con trandingheight">
							<h6>Sunflower Seeds Roasted Salted</h6>
							<h5><span>₹420</span><i>₹599</i></h5>
							<div class="btn1"><a href="products-detail.php">Add to cart</a></div>
						</div>
					</div>
				</li>
				<li>
					<div class="conbox2">
						<a href="products-detail.php">
							<img src="images/tranding1.jpg" alt="" >
						</a>
						<div class="conbox2con trandingheight">
							<h6>Sunflower Seeds Roasted Salted</h6>
							<h5><span>₹420</span><i>₹599</i></h5>
							<div class="btn1"><a href="products-detail.php">Add to cart</a></div>
						</div>
					</div>
				</li>
				<li>
					<div class="conbox2">
						<a href="products-detail.php">
							<img src="images/tranding1.jpg" alt="" >
						</a>
						<div class="conbox2con trandingheight">
							<h6>Sunflower Seeds Roasted Salted</h6>
							<h5><span>₹420</span><i>₹599</i></h5>
							<div class="btn1"><a href="products-detail.php">Add to cart</a></div>
						</div>
					</div>
				</li>
				<li>
					<div class="conbox2">
						<a href="products-detail.php">
							<img src="images/tranding1.jpg" alt="" >
						</a>
						<div class="conbox2con trandingheight">
							<h6>Sunflower Seeds Roasted Salted</h6>
							<h5><span>₹420</span><i>₹599</i></h5>
							<div class="btn1"><a href="products-detail.php">Add to cart</a></div>
						</div>
					</div>
				</li>
			</ul>
		</div>
	</div>
	
	<!--END-->
	
	
	
	
	
	
	
	
	
	<!--Footer Wrapper-->
	<div class="footerbg">
		<div class="footerwrapper">
			<div class="group clearboth">
				<div class="footercol1">
					<h6>Quick Links</h6>
					<a href="blog.php">Blog</a>
					<a href="our-story.php">OUR STORY</a>
					<a href="">ETERNALLY PURE</a>
					<a href="">PROCESS</a>
					<a href="">OUR PILLARS</a>
					<a href="">RECIPES</a>
					<a href="">FAQs</a>
				</div>
				<div class="footercol1">
					<h6>PRODUCTS</h6>
					<a href="products.php">SEED</a>
					<a href="products.php">NUT</a>
					<a href="products.php">COMBOS</a>
					<a href="products.php">SPECIAL PACKS</a>
				</div>
				<div class="footercol1">
					<h6>LEGAL</h6>
					<a href="">TERMS &amp; CONDITIONS</a>
					<a href="">PAYMENT POLICY</a>
					<a href="">CONTACT US</a>
				</div>
				<div class="footercol2">
					<h6>Subscribe to our Newsletter</h6>
					<div class="group clearboth footersearch">
						<input type="text" placeholder="Your Email ID" ><button>Search</button>
					</div>
					<hr>
					<div class="imgper"><img src="images/payment.svg" alt="" ></div>
				</div>
			</div>
			<hr>
			<div class="group clearboth">
				<div class="footerbottomleft"> 
					Copyright &copy; 2022 Soultatva. All Right Reserved | Developed By <a href="" target="_blank">Jency Software</a>
				</div>
				<div class="footerbottomright">
					<div class="footersocial">
						<a href="https://www.facebook.com/Soultatva" target="_blank"><i class="fab fa-facebook"></i></a>
                        <a href="https://www.linkedin.com/showcase/soul-tatva" target="_blank"><i class="fab fa-linkedin"></i></a>
                        <a href="https://twitter.com/SoulTatva" target="_blank"><i class="fab fa-twitter"></i></a>
                        <a href="https://www.instagram.com/soultatva/" target="_blank"><i class="fab fa-instagram"></i></a>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!--END-->
	
	
	
    
 

<script type="text/javascript" src="js/jquery-3.3.1.min.js"></script>
<script type="text/javascript" src="js/ajax-1.9.0.min.js"></script>

<script type="text/javascript">
	$(document).ready(function(){
		$(window).scroll(function(){
			if ($(this).scrollTop() > 50) {
				$('#Arrowfix').fadeIn();
			} else {
				$('#Arrowfix').fadeOut();
			}
		});
		$('#Arrowfix').click(function(){
			$("html, body").animate({ scrollTop: 0 }, 400);
			return false;
		});
	});
</script>
	
<script type="text/javascript">
	var list = $("nav>ul li > a");
	$("nav > a").click(function (event) {
		$("nav>ul").slideToggle();
	});
	list.click(function (event) {
		var submenu = this.parentNode.getElementsByTagName("ul").item(0);
		if (submenu != null) {
			event.preventDefault();
			//$(submenu).slideToggle();
		}
	});
		$(window).resize(function () {
			if ($(window).width() > 1180) {
				$("nav > ul, nav > ul  li  ul").removeAttr("style");
			}
		});
		$(".scroll").click(function (event) { 
			if ($(window).width() < 1180) {
			$("nav>ul").slideToggle();
		}
	 });
</script>	

<script src="js/jquery.balance.js" type="text/javascript"></script>
<script type="text/javascript">
	$(window).load(function() {
		$('.trandingheight').balance() ;
		$('.assetsboxheight').balance() ;
		$('.idxvideoheight').balance() ;
	});
</script>
	
	
<script src="js/jquery.bxslider.js" type="text/javascript"></script>	
<script type="text/javascript">
	
	$(document).ready(function(){
	  if($(window).width() < 30500){
		  $('.productsslider').bxSlider({
			infiniteLoop:true,
			auto:true,
			pager:true,
			controls:true,
			  oneToOneTouch:true,
				pause: 8000,
				touchEnabled: true,
			  pagerCustom: '.bx-pager',
		 });
	  }
	});
	
	
	$(document).ready(function(){
		if($(window).width()>1500){
			$('.assetsslide').bxSlider({
				infiniteLoop:true,
				auto:false,
				slideWidth: 370,
				maxSlides: 4,
				pager:false,
				controls:true,
				oneToOneTouch:false,
				pause: 10000,
				touchEnabled: true,
				moveSlides:1,
				 preventDefaultSwipeX:true,
				preventDefaultSwipeY:true
			});
		}
	   
		else{
		if($(window).width()<=1500 && $(window).width() > 1280) {			
			$('.assetsslide').bxSlider({
				slideWidth: 290,
				auto:false,
				maxSlides: 4,
				moveSlides:1,
				pager:false,
				controls:true,
				autoHover: true,
				oneToOneTouch:false,
				pause: 10000,
				touchEnabled: true
			});
		}
		
		else{
		if($(window).width()<=1280 && $(window).width() > 800) {			
			$('.assetsslide').bxSlider({
				slideWidth: 300,
				auto:false,
				maxSlides: 4,
				moveSlides:1,
				pager:false,
				controls:true,
				autoHover: true,
				oneToOneTouch:false,
				pause: 10000,
				touchEnabled: true
			});
		}
		
		else if($(window).width()<=800) {
			$('.assetsslide').bxSlider({
				slideWidth: 400,
				maxSlides: 1
				,pager:false,
				controls:true,
				autoHover: true,
				oneToOneTouch:false,
				pause: 10000,
				touchEnabled: true
			});
		}	   
	   }
			}
	});
	
	
</script>
	
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.2/jquery.fancybox.min.js"></script>
<script type="text/javascript">
	
	$(document).ready(function() {
		$("data-fancybox").fancybox();
	});
	$(document).ready(function() {
		$(".fancybox").fancybox();
	});
	
	
	$(document).ready(function(){
	  $(".showsingle").click(function(){
		$("#leftmenu"+$(this).attr('target')).toggle();
	  });
	});
	
	
</script>
	
<script>
	function openCity(evt, cityName) {
	  var i, tabcontent, tablinks;
	  tabcontent = document.getElementsByClassName("tabcontent");
	  for (i = 0; i < tabcontent.length; i++) {
		tabcontent[i].style.display = "none";
	  }
	  tablinks = document.getElementsByClassName("tablinks");
	  for (i = 0; i < tablinks.length; i++) {
		tablinks[i].className = tablinks[i].className.replace(" active", "");
	  }
	  document.getElementById(cityName).style.display = "block";
	  evt.currentTarget.className += " active";
	}
</script>

	
<script type="text/javascript">
	$(window).load(function() {
		$(".loader").fadeOut("slow");
	})
</script>	

</body>
</html>
