<html lang="en">
<head>
<title>Buy Organic Seeds, Dry Fruits &amp; Nuts from Soultatva</title>

<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0, minimal-ui" />


<link rel="icon" type="image/png" href="favicon.png">
<link rel="shortcut icon" href="favicon.ico">


<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Nunito:ital,wght@0,200;0,300;0,400;0,600;0,700;0,800;0,900;1,200;1,300;1,400;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">



<link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">



<link href="css/jquery.bxslider.css" rel="stylesheet" type="text/css" />
	
<link href="css/common-text.css" rel="stylesheet" type="text/css" />
<link href="css/common-layout.css" rel="stylesheet" type="text/css" />
<link href="css/menu.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="css/resrponsive.css">
<link rel="stylesheet" href="css/jquery.fancybox.min.css" type="text/css" media="screen" />
<link href="css/jquery.bxslider.css" rel="stylesheet" type="text/css" />


</head>

<body>
	
	
	<div class="loader"><span></span></div>
	
    
    <a href="javascript:void(0);" id="Arrowfix" style="display: none;"><span></span></a>
    
	
	
	
	<!--TOPMAIN-->
	<div class="topmain">
		<div class="topmainleft">
			<select name="langues" id="langues">
			  <option value="English">English</option>
			  <option value="Hindi">Hindi</option>
			  <option value="Gujarati">Gujarati</option>
			  <option value="Marathi">Marathi</option>
			</select>
		</div>
		<div class="topmainright">
			<a href="myaccount.php">My Account</a> <span>|</span>
			<a href="mywhishlist.php">My Wishlist</a> <span>|</span>
			<a href="signin.php">Sign in</a> <span>|</span>
			<a href="register.php">Register</a> <span>|</span>
			<a href="store.php">Store Locator</a> <span>|</span>
			<a href="blog.php">Blog</a>
		</div>
	</div>
	<!--TOPMAIN-->
    
	
	
	<!--TOPMAIN Wrapper-->
	<div class="topmainwrapper">
		<div class="topmaincol1"><a href="index.php"><img src="images/soultatva-logo1.png" alt="" ></a></div>
		<div class="topmaincol2">
			<input type="text" placeholder="Search for products" ><button>Search</button>
		</div>
		<div class="topmaincol3">
			<div class="group clearboth">
				<h6><a href="tel:Call 1300 000 XXX">Call 1300 000 XXX</a></h6>
				<h5><a href="checkout.php">Cart <i class="fa fa-shopping-cart" aria-hidden="true"></i> <span>0</span></a></h5>
			</div>
		</div>
	</div>
	<!--TOPMAIN-->
	
	
	<!--Menu-->
	
	<div class="menubg">
		<nav>
			<a href="#"><i class="fa fa-bars fa-2x"></i></a>
			<ul>
				<li><a href="index.php">Home</a></li>
				<li><a href="about.php">About US</a> <i class="fa fa-caret-down"></i>
					<ul>
						<li><a href="our-story.php">Our Story</a></li>
						<li><a href="eternallypure.php">Eternally Pure</a></li>
						<li><a href="process.php">process</a></li>
					</ul>
				</li>
				<li><a href="products.php">Products</a> <i class="fa fa-caret-down"></i>
					<ul>
						<li><a href="products.php">Products</a></li>
						<li><a href="seed.php">Seed <i class="fa fa-caret-right"></i></a>
							<ul>
								<li><a href="products.php">Seed Name 1</a></li>
								<li><a href="products.php">Seed Name 2</a></li>
								<li><a href="products.php">Seed Name 3</a></li>
							</ul>
						</li>
						<li><a href="nut.php">Nut <i class="fa fa-caret-right"></i></a>
							<ul>
								<li><a href="products.php">Nut Name 1</a></li>
								<li><a href="products.php">Nut Name 2</a></li>
								<li><a href="products.php">Nut Name 3</a></li>
							</ul>
						</li>
						<li><a href="combos.php">Combos <i class="fa fa-caret-right"></i></a>
							<ul>
								<li><a href="products.php">Combos Name 1</a></li>
								<li><a href="products.php">Combos Name 2</a></li>
								<li><a href="products.php">Combos Name 3</a></li>
							</ul>
						</li>
					</ul>
				</li>
				<li><a href="our-pillars.php">Our Pillars</a></li>
				<li><a href="recipes.php">Recipes</a></li>
				<li><a href="blog.php">Blog</a></li>
				<li><a href="contact-us.php">Contact us</a></li>
			</ul>
		</nav>
	</div>
	
	<!--END-->
	
	
	<!--Contain Wrapper-->
	
	<div class="containwrapper">
		
		<div class="bredcum">
			<h1>Soultatva Our Pillars</h1>
			<a href="index.php">Home</a> <i class="fa fa-angle-double-right"></i> <span>Soultatva Our Pillars</span>
		</div>
		
		<h3>Know About Soultatva</h3>
		<p>Soul Tatva is not just organic produce; it’s a way of life. Try new foods, eat mindfully, and listen to your body. It speaks volumes if you hear closely. There are many ways to love your body. Nourishing it with the healthiest form of nutrients is another way of showing it your respect and gratitude.</p>
		
		<div class="group clearboth">
			
			<div class="idfaqcol1">
				<div class="faq-c">
					<div class="faq-q"><span class="faq-t">+</span><i>Super Benefits: Re-invent yourself, the key to an active life</i></div>
					<div class="faq-a">
						<div class="group clearboth tac">
							<div class="faqbox1">
								<img src="images/faq/1.png" alt="" >
								<h6>Brain Health</h6>
							</div>
							<div class="faqbox1">
								<img src="images/faq/2.png" alt="" >
								<h6>Healthy Heart</h6>
							</div>
							<div class="faqbox1">
								<img src="images/faq/3.png" alt="" >
								<h6>Immunity Booster</h6>
							</div>
							<div class="faqbox1">
								<img src="images/faq/4.png" alt="" >
								<h6>Anti-oxidant</h6>
							</div>
							<div class="faqbox1">
								<img src="images/faq/5.png" alt="" >
								<h6>Protein Rich</h6>
							</div>
							<div class="faqbox1">
								<img src="images/faq/6.png" alt="" >
								<h6>Bone Health</h6>
							</div>
							<div class="faqbox1">
								<img src="images/faq/7.png" alt="" >
								<h6>Keto Meal</h6>
							</div>
							<div class="faqbox1">
								<img src="images/faq/8.png" alt="" >
								<h6>Anti-Inflammatory</h6>
							</div>
							<div class="faqbox1">
								<img src="images/faq/9.png" alt="" >
								<h6>Weight Balance</h6>
							</div>
							<div class="faqbox1">
								<img src="images/faq/10.png" alt="" >
								<h6>Muscle strength</h6>
							</div>
							<div class="faqbox1">
								<img src="images/faq/11.png" alt="" >
								<h6>Skin Rejuvenation</h6>
							</div>
							<div class="faqbox1">
								<img src="images/faq/12.png" alt="" >
								<h6>Digestion Power</h6>
							</div>
							<div class="faqbox1">
								<img src="images/faq/13.png" alt="" >
								<h6>Energy Packed</h6>
							</div>
							<div class="faqbox1">
								<img src="images/faq/14.png" alt="" >
								<h6>Detox</h6>
							</div>
							<div class="faqbox1">
								<img src="images/faq/15.jpg" alt="" >
								<h6>Dietary</h6>
							</div>
							<div class="faqbox1">
								<img src="images/faq/16.jpg" alt="" >
								<h6>Riboflavin</h6>
							</div>
						</div>
					</div>
				</div>
			</div>
			
			<div class="idfaqcol1">
				<div class="faq-c">
					<div class="faq-q"><span class="faq-t">+</span><i>Packaging:  Carry your nourishment wherever you go</i></div>
					<div class="faq-a">
						<div>
							<div class="faqbox2"><img src="images/faq/17.png" alt="" > Easy to access </div> <div class="faqbox2"><img src="images/faq/17.png" alt="" > Easy to carry,</div> <div class="faqbox2"><img src="images/faq/17.png" alt="" > Easy to eat</div>
							<p>Because your access to these foods is not just limited within the confines of your house or a box. Have them on your plate anywhere, anytime you want with the ease of carrying of the packages.</p>
							<img src="images/faq/19.png" alt="" class="faqbox2img" >
						</div>
					</div>
				</div>
			</div>
			
			<div class="idfaqcol1">
				<div class="faq-c">
					<div class="faq-q"><span class="faq-t">+</span><i>Range of products: A plethora of colour and nutrients</i></div>
					<div class="faq-a">
						<div>
							<p>Our products range from nuts, spreads, candies, herbs, berries and beans to super foods and seeds. A plethora of colors and nutrients and diverse taste options on your plate.</p>
							<img src="images/faq/18.png" alt="" class="faqbox3img" >
						</div>
					</div>
				</div>
			</div>
			
			<div class="idfaqcol1">
				<div class="faq-c">
					<div class="faq-q"><span class="faq-t">+</span><i>Product Awareness:  Know the power of superfoods The key to a fitter you</i></div>
					<div class="faq-a">
						<div>
							<p>Super foods that energizes you right from the first bite. It is our responsibility to let you know that every time you eat, it is an opportunity to nourish your body. We want to reward you and soul with the best source of nutrition there is. A wide range of organic and super foods because you’re invincible and your health deserves the same.</p>
							<img src="images/faq/20.png" alt="" class="faqbox2img" >
						</div>
					</div>
				</div>
			</div>
			
			<div class="idfaqcol1">
				<div class="faq-c">
					<div class="faq-q"><span class="faq-t">+</span><i>Fresh & natural, The purest in form</i></div>
					<div class="faq-a">
						<div>
							<img src="images/faq/21.jpg" alt="" class="faqbox3img" >
						</div>
					</div>
				</div>
			</div>
			
			<div class="idfaqcol1">
				<div class="faq-c">
					<div class="faq-q"><span class="faq-t">+</span><i>Ways of eating: Redesign your platter</i></div>
					<div class="faq-a">
						<p>Incorporate Soul Tatva in your regular diet plan and watch the drastic changes it brings about physically, mentally and with us, even spiritually. Replace calorie and fat laden foods with more filling, tastier choices that bring about the best in you. Each of our products is a delight to your taste palette and a treat to your senses. Whether you use it while cooking, as supplement or as healthier food substitute, you’ll find that Soul Tatva products are the healthy addition to your meal that your soul, body and mind, will be grateful for.</p>
						<div class="group clearboth tac">
							<div class="faqbox1">
								<img src="images/faq/21.png" alt="" class="faqbox4img" >
							</div>
							<div class="faqbox1">
								<img src="images/faq/22.png" alt="" class="faqbox4img" >
							</div>
							<div class="faqbox1">
								<img src="images/faq/23.png" alt="" class="faqbox4img" >
							</div>
							<div class="faqbox1">
								<img src="images/faq/24.png" alt="" class="faqbox4img" >
							</div>
							
						</div>
					</div>
				</div>
			</div>
			
			
		</div>
		
		
		
		
		
		
		
			
		
	</div>
	
	<!--END-->
	
	
	
	
	<!--Footer Wrapper-->
	<div class="footerbg">
		<div class="footerwrapper">
			<div class="group clearboth">
				<div class="footercol1">
					<h6>Quick Links</h6>
					<a href="blog.php">Blog</a>
					<a href="our-story.php">OUR STORY</a>
					<a href="eternallypure.php">ETERNALLY PURE</a>
					<a href="process.php">PROCESS</a>
					<a href="our-pillars.php">OUR PILLARS</a>
					<a href="recipes.php">RECIPES</a>
					<a href="faq.php">FAQs</a>
				</div>
				<div class="footercol1">
					<h6>PRODUCTS</h6>
					<a href="products.php">SEED</a>
					<a href="products.php">NUT</a>
					<a href="products.php">COMBOS</a>
					<a href="products.php">SPECIAL PACKS</a>
				</div>
				<div class="footercol1">
					<h6>LEGAL</h6>
					<a href="term.php">TERMS &amp; CONDITIONS</a>
					<a href="payment-policy.php">PAYMENT POLICY</a>
					<a href="contact-us.php">CONTACT US</a>
				</div>
				<div class="footercol2">
					<h6>Subscribe to our Newsletter</h6>
					<div class="group clearboth footersearch">
						<input type="text" placeholder="Your Email ID" ><button>Search</button>
					</div>
					<hr>
					<div class="imgper"><img src="images/payment.svg" alt="" ></div>
				</div>
			</div>
			<hr>
			<div class="group clearboth">
				<div class="footerbottomleft"> 
					Copyright &copy; 2022 Soultatva. All Right Reserved | Developed By <a href="" target="_blank">Jency Software</a>
				</div>
				<div class="footerbottomright">
					<div class="footersocial">
						<a href="https://www.facebook.com/Soultatva" target="_blank"><i class="fab fa-facebook"></i></a>
                        <a href="https://www.linkedin.com/showcase/soul-tatva" target="_blank"><i class="fab fa-linkedin"></i></a>
                        <a href="https://twitter.com/SoulTatva" target="_blank"><i class="fab fa-twitter"></i></a>
                        <a href="https://www.instagram.com/soultatva/" target="_blank"><i class="fab fa-instagram"></i></a>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!--END-->
	
	
	
    
 

<script type="text/javascript" src="js/jquery-3.3.1.min.js"></script>
<script type="text/javascript" src="js/ajax-1.9.0.min.js"></script>

<script type="text/javascript">
	$(document).ready(function(){
		$(window).scroll(function(){
			if ($(this).scrollTop() > 50) {
				$('#Arrowfix').fadeIn();
			} else {
				$('#Arrowfix').fadeOut();
			}
		});
		$('#Arrowfix').click(function(){
			$("html, body").animate({ scrollTop: 0 }, 400);
			return false;
		});
	});
</script>
	
<script type="text/javascript">
	var list = $("nav>ul li > a");
	$("nav > a").click(function (event) {
		$("nav>ul").slideToggle();
	});
	list.click(function (event) {
		var submenu = this.parentNode.getElementsByTagName("ul").item(0);
		if (submenu != null) {
			event.preventDefault();
			//$(submenu).slideToggle();
		}
	});
		$(window).resize(function () {
			if ($(window).width() > 1180) {
				$("nav > ul, nav > ul  li  ul").removeAttr("style");
			}
		});
		$(".scroll").click(function (event) { 
			if ($(window).width() < 1180) {
			$("nav>ul").slideToggle();
		}
	 });
</script>	

<script src="js/jquery.balance.js" type="text/javascript"></script>
<script type="text/javascript">
	$(window).load(function() {
		$('.processmainboxheight').balance() ;
	});
</script>

<script type="text/javascript">
	$(".faq-q").click( function () {
	  var container = $(this).parents(".faq-c");
	  var answer = container.find(".faq-a");
	  var trigger = container.find(".faq-t");

	  answer.slideToggle(200);

	  if (trigger.hasClass("faq-o")) {
		trigger.removeClass("faq-o");
	  }
	  else {
		trigger.addClass("faq-o");
	  }
	});
</script>
	
	
<script type="text/javascript">
	$(window).load(function() {
		$(".loader").fadeOut("slow");
	})
</script>	

</body>
</html>
