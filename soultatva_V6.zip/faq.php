<html lang="en">
<head>
<title>Buy Organic Seeds, Dry Fruits &amp; Nuts from Soultatva</title>

<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0, minimal-ui" />


<link rel="icon" type="image/png" href="favicon.png">
<link rel="shortcut icon" href="favicon.ico">


<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Nunito:ital,wght@0,200;0,300;0,400;0,600;0,700;0,800;0,900;1,200;1,300;1,400;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">



<link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">



<link href="css/jquery.bxslider.css" rel="stylesheet" type="text/css" />
	
<link href="css/common-text.css" rel="stylesheet" type="text/css" />
<link href="css/common-layout.css" rel="stylesheet" type="text/css" />
<link href="css/menu.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="css/resrponsive.css">
<link rel="stylesheet" href="css/jquery.fancybox.min.css" type="text/css" media="screen" />
<link href="css/jquery.bxslider.css" rel="stylesheet" type="text/css" />


</head>

<body>
	
	
	<div class="loader"><span></span></div>
	
    
    <a href="javascript:void(0);" id="Arrowfix" style="display: none;"><span></span></a>
    
	
	
	
	<!--TOPMAIN-->
	<div class="topmain">
		<div class="topmainleft">
			<select name="langues" id="langues">
			  <option value="English">English</option>
			  <option value="Hindi">Hindi</option>
			  <option value="Gujarati">Gujarati</option>
			  <option value="Marathi">Marathi</option>
			</select>
		</div>
		<div class="topmainright">
			<a href="myaccount.php">My Account</a> <span>|</span>
			<a href="mywhishlist.php">My Wishlist</a> <span>|</span>
			<a href="signin.php">Sign in</a> <span>|</span>
			<a href="register.php">Register</a> <span>|</span>
			<a href="store.php">Store Locator</a> <span>|</span>
			<a href="blog.php">Blog</a>
		</div>
	</div>
	<!--TOPMAIN-->
    
	
	
	<!--TOPMAIN Wrapper-->
	<div class="topmainwrapper">
		<div class="topmaincol1"><a href="index.php"><img src="images/soultatva-logo1.png" alt="" ></a></div>
		<div class="topmaincol2">
			<input type="text" placeholder="Search for products" ><button>Search</button>
		</div>
		<div class="topmaincol3">
			<div class="group clearboth">
				<h6><a href="tel:Call 1300 000 XXX">Call 1300 000 XXX</a></h6>
				<h5><a href="checkout.php">Cart <i class="fa fa-shopping-cart" aria-hidden="true"></i> <span>0</span></a></h5>
			</div>
		</div>
	</div>
	<!--TOPMAIN-->
	
	
	<!--Menu-->
	
	<div class="menubg">
		<nav>
			<a href="#"><i class="fa fa-bars fa-2x"></i></a>
			<ul>
				<li><a href="index.php">Home</a></li>
				<li><a href="about.php">About US</a> <i class="fa fa-caret-down"></i>
					<ul>
						<li><a href="our-story.php">Our Story</a></li>
						<li><a href="eternallypure.php">Eternally Pure</a></li>
						<li><a href="process.php">process</a></li>
					</ul>
				</li>
				<li><a href="products.php">Products</a> <i class="fa fa-caret-down"></i>
					<ul>
						<li><a href="products.php">Products</a></li>
						<li><a href="seed.php">Seed <i class="fa fa-caret-right"></i></a>
							<ul>
								<li><a href="products.php">Seed Name 1</a></li>
								<li><a href="products.php">Seed Name 2</a></li>
								<li><a href="products.php">Seed Name 3</a></li>
							</ul>
						</li>
						<li><a href="nut.php">Nut <i class="fa fa-caret-right"></i></a>
							<ul>
								<li><a href="products.php">Nut Name 1</a></li>
								<li><a href="products.php">Nut Name 2</a></li>
								<li><a href="products.php">Nut Name 3</a></li>
							</ul>
						</li>
						<li><a href="combos.php">Combos <i class="fa fa-caret-right"></i></a>
							<ul>
								<li><a href="products.php">Combos Name 1</a></li>
								<li><a href="products.php">Combos Name 2</a></li>
								<li><a href="products.php">Combos Name 3</a></li>
							</ul>
						</li>
					</ul>
				</li>
				<li><a href="our-pillars.php">Our Pillars</a></li>
				<li><a href="recipes.php">Recipes</a></li>
				<li><a href="blog.php">Blog</a></li>
				<li><a href="contact-us.php">Contact us</a></li>
			</ul>
		</nav>
	</div>
	
	<!--END-->
	
	
	<!--Contain Wrapper-->
	
	<div class="containwrapper">
		
		<div class="bredcum">
			<h1>Soultatva Our FAQ</h1>
			<a href="index.php">Home</a> <i class="fa fa-angle-double-right"></i> <span>Soultatva Our FAQ</span>
		</div>
		
		
		<div class="group clearboth">
			
			<div class="idfaqcol1">
				<div class="faq-c">
					<div class="faq-q"><span class="faq-t">+</span><i>What is a superfood?</i></div>
					<div class="faq-a">
						<div>
							<p>You've likely heard the word "superfood", or perhaps have seen it on food packaging or in ads. But what does it actually mean? At Soultatva, we like to define "superfood" as a plant-based food that is nutrient-dense, meaning it has a high concentration of nutrients to overall calories. Another way to think of it is that, for every bite, you're getting more of the good stuff—vitamins, minerals, antioxidants, fiber, and omegas—and less of the bad, like refined or processed ingredients. Superfoods can shine in different ways. Some contain large quantities of common nutrients like protein and minerals. Other superfoods contain nutrients that are unique or uncommon, including rare antioxidants, healthy fats (like omega-3s) and other beneficial plant compounds. In addition, for us, a superfood is also organic, non-GMO and minimally processed in order to protect its "super" quality and nutrient integrity. You can expect this from the products we offer.</p>
						</div>
					</div>
				</div>
			</div>
			
			
			<div class="idfaqcol1">
				<div class="faq-c">
					<div class="faq-q"><span class="faq-t">+</span><i>Are your products safe for children?</i></div>
					<div class="faq-a">
						<div>
							<p>All of our superfoods are known to be safe for all ages and health states. However, we recommend consulting with your health professional if you have any specific questions or particular health concerns. A lot of our happy clients have switched a bag of chips with our sachet of seeds & nuts. We always take advice from our super mom clients.</p>
						</div>
					</div>
				</div>
			</div>
			
			
			<div class="idfaqcol1">
				<div class="faq-c">
					<div class="faq-q"><span class="faq-t">+</span><i>What products do you offer?</i></div>
					<div class="faq-a">
						<div>
							<p>We have healthy alternatives that can be consumed at any time of the day. At Soultatva, we have a range of nuts, seeds, berries, trail mixes, dates to nourish your taste buds in the most wholesome way possible.</p>
						</div>
					</div>
				</div>
			</div>
			
			
			<div class="idfaqcol1">
				<div class="faq-c">
					<div class="faq-q"><span class="faq-t">+</span><i>How many nuts should I eat every day?</i></div>
					<div class="faq-a">
						<div>
							<p>A healthy daily intake of nuts is a handful or approximately or approx. 20-25g. It's a myth that nuts are fattening! In fact, they contain ‘healthy fats’ which are extremely good for the body and help in weight management. However, they should be taken in the right quantity, only a handful which is around 10-15 pieces a day does wonders over a long period of time. At Soultatva, we believe that it's better to pay the “farmer” rather than the “pharma” later.</p>
						</div>
					</div>
				</div>
			</div>
			
			
			<div class="idfaqcol1">
				<div class="faq-c">
					<div class="faq-q"><span class="faq-t">+</span><i>What are the health benefits of consuming various seeds?</i></div>
					<div class="faq-a">
						<div>
							<p>Have you ever been fascinated with the fact that a small & tiny looking seed can somehow grow into a tree/plant which is almost 10000 times its size or even more. Well thats because seeds are densely packed with plenty of nutrition. Hence, consuming even a spoonful everyday can be life changing in terms of enhancing better health, wellness, beauty, energy, endurance etc. A lot of seeds are High in Omega-3 Fats. They are high in plant based protein, may control cholesterol and blood pressure, improve digestive health, reduce the risk of cancer and may benefit people with diabetes. Each and every edible seed has an array of health benefits which is why one should adopt them in everyday meals.</p>
						</div>
					</div>
				</div>
			</div>
			
			
			<div class="idfaqcol1">
				<div class="faq-c">
					<div class="faq-q"><span class="faq-t">+</span><i>What all gifting options are available?</i></div>
					<div class="faq-a">
						<div>
							<p>We offer gift hampers for festivals, weddings, corporate events and personal gifting. You can contact us further for more details at +91 90678 20009 or drop us an email at info@efiveorganics.com.</p>
						</div>
					</div>
				</div>
			</div>
			
			
			<div class="idfaqcol1">
				<div class="faq-c">
					<div class="faq-q"><span class="faq-t">+</span><i>Do you cater to weddings, corporate giftings and festivals?</i></div>
					<div class="faq-a">
						<div>
							<p>Yes, we offer customised gift hampers to weddings, corporate giftings and other festive occasions. You can contact us further for more details at +91 90678 20009 or drop us an email at info@efiveorganics.com.</p>
						</div>
					</div>
				</div>
			</div>
			
			
			
			
			
			
			
			
			
		</div>
		
		
		
		
		
		
		
			
		
	</div>
	
	<!--END-->
	
	
	
	
	<!--Footer Wrapper-->
	<div class="footerbg">
		<div class="footerwrapper">
			<div class="group clearboth">
				<div class="footercol1">
					<h6>Quick Links</h6>
					<a href="blog.php">Blog</a>
					<a href="our-story.php">OUR STORY</a>
					<a href="eternallypure.php">ETERNALLY PURE</a>
					<a href="process.php">PROCESS</a>
					<a href="our-pillars.php">OUR PILLARS</a>
					<a href="recipes.php">RECIPES</a>
					<a href="faq.php">FAQs</a>
				</div>
				<div class="footercol1">
					<h6>PRODUCTS</h6>
					<a href="products.php">SEED</a>
					<a href="products.php">NUT</a>
					<a href="products.php">COMBOS</a>
					<a href="products.php">SPECIAL PACKS</a>
				</div>
				<div class="footercol1">
					<h6>LEGAL</h6>
					<a href="term.php">TERMS &amp; CONDITIONS</a>
					<a href="payment-policy.php">PAYMENT POLICY</a>
					<a href="contact-us.php">CONTACT US</a>
				</div>
				<div class="footercol2">
					<h6>Subscribe to our Newsletter</h6>
					<div class="group clearboth footersearch">
						<input type="text" placeholder="Your Email ID" ><button>Search</button>
					</div>
					<hr>
					<div class="imgper"><img src="images/payment.svg" alt="" ></div>
				</div>
			</div>
			<hr>
			<div class="group clearboth">
				<div class="footerbottomleft"> 
					Copyright &copy; 2022 Soultatva. All Right Reserved | Developed By <a href="" target="_blank">Jency Software</a>
				</div>
				<div class="footerbottomright">
					<div class="footersocial">
						<a href="https://www.facebook.com/Soultatva" target="_blank"><i class="fab fa-facebook"></i></a>
                        <a href="https://www.linkedin.com/showcase/soul-tatva" target="_blank"><i class="fab fa-linkedin"></i></a>
                        <a href="https://twitter.com/SoulTatva" target="_blank"><i class="fab fa-twitter"></i></a>
                        <a href="https://www.instagram.com/soultatva/" target="_blank"><i class="fab fa-instagram"></i></a>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!--END-->
	
	
	
    
 

<script type="text/javascript" src="js/jquery-3.3.1.min.js"></script>
<script type="text/javascript" src="js/ajax-1.9.0.min.js"></script>

<script type="text/javascript">
	$(document).ready(function(){
		$(window).scroll(function(){
			if ($(this).scrollTop() > 50) {
				$('#Arrowfix').fadeIn();
			} else {
				$('#Arrowfix').fadeOut();
			}
		});
		$('#Arrowfix').click(function(){
			$("html, body").animate({ scrollTop: 0 }, 400);
			return false;
		});
	});
</script>
	
<script type="text/javascript">
	var list = $("nav>ul li > a");
	$("nav > a").click(function (event) {
		$("nav>ul").slideToggle();
	});
	list.click(function (event) {
		var submenu = this.parentNode.getElementsByTagName("ul").item(0);
		if (submenu != null) {
			event.preventDefault();
			//$(submenu).slideToggle();
		}
	});
		$(window).resize(function () {
			if ($(window).width() > 1180) {
				$("nav > ul, nav > ul  li  ul").removeAttr("style");
			}
		});
		$(".scroll").click(function (event) { 
			if ($(window).width() < 1180) {
			$("nav>ul").slideToggle();
		}
	 });
</script>	

<script src="js/jquery.balance.js" type="text/javascript"></script>
<script type="text/javascript">
	$(window).load(function() {
		$('.processmainboxheight').balance() ;
	});
</script>

<script type="text/javascript">
	$(".faq-q").click( function () {
	  var container = $(this).parents(".faq-c");
	  var answer = container.find(".faq-a");
	  var trigger = container.find(".faq-t");

	  answer.slideToggle(200);

	  if (trigger.hasClass("faq-o")) {
		trigger.removeClass("faq-o");
	  }
	  else {
		trigger.addClass("faq-o");
	  }
	});
</script>
	
	
<script type="text/javascript">
	$(window).load(function() {
		$(".loader").fadeOut("slow");
	})
</script>	

</body>
</html>
