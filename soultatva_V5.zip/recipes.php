<html lang="en">
<head>
<title>Buy Organic Seeds, Dry Fruits &amp; Nuts from Soultatva</title>

<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0, minimal-ui" />


<link rel="icon" type="image/png" href="favicon.png">
<link rel="shortcut icon" href="favicon.ico">


<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Nunito:ital,wght@0,200;0,300;0,400;0,600;0,700;0,800;0,900;1,200;1,300;1,400;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">



<link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">



<link href="css/jquery.bxslider.css" rel="stylesheet" type="text/css" />
	
<link href="css/common-text.css" rel="stylesheet" type="text/css" />
<link href="css/common-layout.css" rel="stylesheet" type="text/css" />
<link href="css/menu.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="css/resrponsive.css">
<link rel="stylesheet" href="css/jquery.fancybox.min.css" type="text/css" media="screen" />
<link href="css/jquery.bxslider.css" rel="stylesheet" type="text/css" />


</head>

<body>
	
	
	<div class="loader"><span></span></div>
	
    
    <a href="javascript:void(0);" id="Arrowfix" style="display: none;"><span></span></a>
    
	
	
	
	<!--TOPMAIN-->
	<div class="topmain">
		<div class="topmainleft">
			<select name="langues" id="langues">
			  <option value="English">English</option>
			  <option value="Hindi">Hindi</option>
			  <option value="Gujarati">Gujarati</option>
			  <option value="Marathi">Marathi</option>
			</select>
		</div>
		<div class="topmainright">
			<a href="mywhishlist.php">My Wishlist</a> <span>|</span>
			<a href="signin.php">Sign in</a> <span>|</span>
			<a href="register.php">Register</a> <span>|</span>
			<a href="store.php">Store Locator</a> <span>|</span>
			<a href="blog.php">Blog</a>
		</div>
	</div>
	<!--TOPMAIN-->
    
	
	
	<!--TOPMAIN Wrapper-->
	<div class="topmainwrapper">
		<div class="topmaincol1"><a href="index.php"><img src="images/soultatva-logo1.png" alt="" ></a></div>
		<div class="topmaincol2">
			<input type="text" placeholder="Search for products" ><button>Search</button>
		</div>
		<div class="topmaincol3">
			<div class="group clearboth">
				<h6><a href="tel:Call 1300 000 XXX">Call 1300 000 XXX</a></h6>
				<h5><a href="checkout.php">Cart <i class="fa fa-shopping-cart" aria-hidden="true"></i> <span>0</span></a></h5>
			</div>
		</div>
	</div>
	<!--TOPMAIN-->
	
	
	<!--Menu-->
	
	<div class="menubg">
		<nav>
			<a href="#"><i class="fa fa-bars fa-2x"></i></a>
			<ul>
				<li><a href="index.php">Home</a></li>
				<li><a href="about.php">About US</a> <i class="fa fa-caret-down"></i>
					<ul>
						<li><a href="our-story.php">Our Story</a></li>
						<li><a href="eternallypure.php">Eternally Pure</a></li>
						<li><a href="process.php">process</a></li>
					</ul>
				</li>
				<li><a href="products.php">Products</a> <i class="fa fa-caret-down"></i>
					<ul>
						<li><a href="products.php">Products</a></li>
						<li><a href="seed.php">Seed <i class="fa fa-caret-right"></i></a>
							<ul>
								<li><a href="products.php">Seed Name 1</a></li>
								<li><a href="products.php">Seed Name 2</a></li>
								<li><a href="products.php">Seed Name 3</a></li>
							</ul>
						</li>
						<li><a href="nut.php">Nut <i class="fa fa-caret-right"></i></a>
							<ul>
								<li><a href="products.php">Nut Name 1</a></li>
								<li><a href="products.php">Nut Name 2</a></li>
								<li><a href="products.php">Nut Name 3</a></li>
							</ul>
						</li>
						<li><a href="combos.php">Combos <i class="fa fa-caret-right"></i></a>
							<ul>
								<li><a href="products.php">Combos Name 1</a></li>
								<li><a href="products.php">Combos Name 2</a></li>
								<li><a href="products.php">Combos Name 3</a></li>
							</ul>
						</li>
					</ul>
				</li>
				<li><a href="our-pillars.php">Our Pillars</a></li>
				<li><a href="recipes.php">Recipes</a></li>
				<li><a href="blog.php">Blog</a></li>
				<li><a href="contact-us.php">Contact us</a></li>
			</ul>
		</nav>
	</div>
	
	<!--END-->
	
	
	<!--Contain Wrapper-->
	
	<div class="containwrapper">
		
		<div class="bredcum">
			<h1>Best Soultatva Recipes</h1>
			<a href="index.php">Home</a> <i class="fa fa-angle-double-right"></i> <span>Best Soultatva Recipes</span>
		</div>
		
		<p>Organic foods often have more beneficial nutrients, such as antioxidants, than their conventionally-grown counterparts and people with allergies to foods, chemicals, or preservatives often find their symptoms lessen or go away when they eat only organic foods.</p>
		<p>counterparts and people with allergies to foods, chemicals, or preservatives often find their symptoms lessen or go away when they eat only organic foods.</p>
		
		
		
		<div class="group clearboth" id="mylist">
			<div class="blogbox">
				<div class="bloxboxheight">
					<a href="recipes-detail.php"><img src="images/recipes/1.jpg" alt="" ></a>
					<h6></h6>
					<h4><a href="recipes-detail.php">Spinach Salad With Hazelnuts, Strawberries & Goat Cheese</a></h4>
					<p>Organic foods often have more beneficial nutrients, such as antioxidants, than their conventionally-grown counterparts and people with allergies to foods, chemicals, or preservatives often find their symptoms lessen or go away when they eat only organic foods.</p>
					<div class="btn1"><a href="recipes-detail.php">Read More</a></div>
				</div>
			</div>
			<div class="blogbox">
				<div class="bloxboxheight">
					<a href="recipes-detail.php"><img src="images/recipes/2.jpg" alt="" ></a>
					<h6></h6>
					<h4><a href="recipes-detail.php">Spinach Salad With Hazelnuts, Strawberries & Goat Cheese</a></h4>
					<p>Organic foods often have more beneficial nutrients, such as antioxidants, than their conventionally-grown counterparts and people with allergies to foods, chemicals, or preservatives often find their symptoms lessen or go away when they eat only organic foods.</p>
					<div class="btn1"><a href="recipes-detail.php">Read More</a></div>
				</div>
			</div>
			<div class="blogbox">
				<div class="bloxboxheight">
					<a href="recipes-detail.php"><img src="images/recipes/3.jpg" alt="" ></a>
					<h6></h6>
					<h4><a href="recipes-detail.php">Spinach Salad With Hazelnuts, Strawberries & Goat Cheese</a></h4>
					<p>Organic foods often have more beneficial nutrients, such as antioxidants, than their conventionally-grown counterparts and people with allergies to foods, chemicals, or preservatives often find their symptoms lessen or go away when they eat only organic foods.</p>
					<div class="btn1"><a href="recipes-detail.php">Read More</a></div>
				</div>
			</div>
			<div class="blogbox">
				<div class="bloxboxheight">
					<a href="recipes-detail.php"><img src="images/recipes/2.jpg" alt="" ></a>
					<h6></h6>
					<h4><a href="recipes-detail.php">Spinach Salad With Hazelnuts, Strawberries & Goat Cheese</a></h4>
					<p>Organic foods often have more beneficial nutrients, such as antioxidants, than their conventionally-grown counterparts and people with allergies to foods, chemicals, or preservatives often find their symptoms lessen or go away when they eat only organic foods.</p>
					<div class="btn1"><a href="recipes-detail.php">Read More</a></div>
				</div>
			</div>
			<div class="blogbox">
				<div class="bloxboxheight">
					<a href="recipes-detail.php"><img src="images/recipes/3.jpg" alt="" ></a>
					<h6></h6>
					<h4><a href="recipes-detail.php">Spinach Salad With Hazelnuts, Strawberries & Goat Cheese</a></h4>
					<p>Organic foods often have more beneficial nutrients, such as antioxidants, than their conventionally-grown counterparts and people with allergies to foods, chemicals, or preservatives often find their symptoms lessen or go away when they eat only organic foods.</p>
					<div class="btn1"><a href="recipes-detail.php">Read More</a></div>
				</div>
			</div>
			<div class="blogbox">
				<div class="bloxboxheight">
					<a href="recipes-detail.php"><img src="images/recipes/1.jpg" alt="" ></a>
					<h6></h6>
					<h4><a href="recipes-detail.php">Spinach Salad With Hazelnuts, Strawberries & Goat Cheese</a></h4>
					<p>Organic foods often have more beneficial nutrients, such as antioxidants, than their conventionally-grown counterparts and people with allergies to foods, chemicals, or preservatives often find their symptoms lessen or go away when they eat only organic foods.</p>
					<div class="btn1"><a href="recipes-detail.php">Read More</a></div>
				</div>
			</div>
			<div class="blogbox">
				<div class="bloxboxheight">
					<a href="recipes-detail.php"><img src="images/recipes/3.jpg" alt="" ></a>
					<h6></h6>
					<h4><a href="recipes-detail.php">Spinach Salad With Hazelnuts, Strawberries & Goat Cheese</a></h4>
					<p>Organic foods often have more beneficial nutrients, such as antioxidants, than their conventionally-grown counterparts and people with allergies to foods, chemicals, or preservatives often find their symptoms lessen or go away when they eat only organic foods.</p>
					<div class="btn1"><a href="recipes-detail.php">Read More</a></div>
				</div>
			</div>
			<div class="blogbox">
				<div class="bloxboxheight">
					<a href="recipes-detail.php"><img src="images/recipes/1.jpg" alt="" ></a>
					<h6></h6>
					<h4><a href="recipes-detail.php">Spinach Salad With Hazelnuts, Strawberries & Goat Cheese</a></h4>
					<p>Organic foods often have more beneficial nutrients, such as antioxidants, than their conventionally-grown counterparts and people with allergies to foods, chemicals, or preservatives often find their symptoms lessen or go away when they eat only organic foods.</p>
					<div class="btn1"><a href="recipes-detail.php">Read More</a></div>
				</div>
			</div>
			<div class="blogbox">
				<div class="bloxboxheight">
					<a href="recipes-detail.php"><img src="images/recipes/2.jpg" alt="" ></a>
					<h6></h6>
					<h4><a href="recipes-detail.php">Spinach Salad With Hazelnuts, Strawberries & Goat Cheese</a></h4>
					<p>Organic foods often have more beneficial nutrients, such as antioxidants, than their conventionally-grown counterparts and people with allergies to foods, chemicals, or preservatives often find their symptoms lessen or go away when they eat only organic foods.</p>
					<div class="btn1"><a href="recipes-detail.php">Read More</a></div>
				</div>
			</div>
			
			
			
			
		</div>
		
		
		<br>
		<div class="group clearboth"><div class="btn2"><a id="loadmore">Show More</a></div></div>
		
		
		
		
		
		
			
		
	</div>
	
	<!--END-->
	
	
	
	
	<!--Footer Wrapper-->
	<div class="footerbg">
		<div class="footerwrapper">
			<div class="group clearboth">
				<div class="footercol1">
					<h6>Quick Links</h6>
					<a href="blog.php">Blog</a>
					<a href="our-story.php">OUR STORY</a>
					<a href="">ETERNALLY PURE</a>
					<a href="">PROCESS</a>
					<a href="">OUR PILLARS</a>
					<a href="">RECIPES</a>
					<a href="">FAQs</a>
				</div>
				<div class="footercol1">
					<h6>PRODUCTS</h6>
					<a href="products.php">SEED</a>
					<a href="products.php">NUT</a>
					<a href="products.php">COMBOS</a>
					<a href="products.php">SPECIAL PACKS</a>
				</div>
				<div class="footercol1">
					<h6>LEGAL</h6>
					<a href="">TERMS &amp; CONDITIONS</a>
					<a href="">PAYMENT POLICY</a>
					<a href="">CONTACT US</a>
				</div>
				<div class="footercol2">
					<h6>Subscribe to our Newsletter</h6>
					<div class="group clearboth footersearch">
						<input type="text" placeholder="Your Email ID" ><button>Search</button>
					</div>
					<hr>
					<div class="imgper"><img src="images/payment.svg" alt="" ></div>
				</div>
			</div>
			<hr>
			<div class="group clearboth">
				<div class="footerbottomleft"> 
					Copyright &copy; 2022 Soultatva. All Right Reserved | Developed By <a href="" target="_blank">Jency Software</a>
				</div>
				<div class="footerbottomright">
					<div class="footersocial">
						<a href="https://www.facebook.com/Soultatva" target="_blank"><i class="fab fa-facebook"></i></a>
                        <a href="https://www.linkedin.com/showcase/soul-tatva" target="_blank"><i class="fab fa-linkedin"></i></a>
                        <a href="https://twitter.com/SoulTatva" target="_blank"><i class="fab fa-twitter"></i></a>
                        <a href="https://www.instagram.com/soultatva/" target="_blank"><i class="fab fa-instagram"></i></a>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!--END-->
	
	
	
    
 

<script type="text/javascript" src="js/jquery-3.3.1.min.js"></script>
<script type="text/javascript" src="js/ajax-1.9.0.min.js"></script>

<script type="text/javascript">
	$(document).ready(function(){
		$(window).scroll(function(){
			if ($(this).scrollTop() > 50) {
				$('#Arrowfix').fadeIn();
			} else {
				$('#Arrowfix').fadeOut();
			}
		});
		$('#Arrowfix').click(function(){
			$("html, body").animate({ scrollTop: 0 }, 400);
			return false;
		});
	});
</script>
	
<script type="text/javascript">
	var list = $("nav>ul li > a");
	$("nav > a").click(function (event) {
		$("nav>ul").slideToggle();
	});
	list.click(function (event) {
		var submenu = this.parentNode.getElementsByTagName("ul").item(0);
		if (submenu != null) {
			event.preventDefault();
			//$(submenu).slideToggle();
		}
	});
		$(window).resize(function () {
			if ($(window).width() > 1180) {
				$("nav > ul, nav > ul  li  ul").removeAttr("style");
			}
		});
		$(".scroll").click(function (event) { 
			if ($(window).width() < 1180) {
			$("nav>ul").slideToggle();
		}
	 });
</script>	

<script src="js/jquery.balance.js" type="text/javascript"></script>
<script type="text/javascript">
	$(window).load(function() {
		$('.bloxboxheight').balance() ;
	});
</script>

<script type="text/javascript">	
	$(document).ready(function () {
		size_li = $("#mylist .blogbox").size();
		x=6;
		$('#mylist .blogbox:lt('+x+')').show();
		$('#loadmore').click(function () {
			x= (x+3 <= size_li) ? x+3 : size_li;
			$('#mylist .blogbox:lt('+x+')').show();
		});
		$('#showless').click(function () {
			x=(x-3<0) ? 3 : x-3;
			$('#mylist .blogbox').not(':lt('+x+')').hide();
		});
	});
</script>
	
	
<script type="text/javascript">
	$(window).load(function() {
		$(".loader").fadeOut("slow");
	})
</script>	

</body>
</html>
