<html lang="en">
<head>
<title>Buy Organic Seeds, Dry Fruits &amp; Nuts from Soultatva</title>

<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0, minimal-ui" />


<link rel="icon" type="image/png" href="favicon.png">
<link rel="shortcut icon" href="favicon.ico">


<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Nunito:ital,wght@0,200;0,300;0,400;0,600;0,700;0,800;0,900;1,200;1,300;1,400;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">



<link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">



<link href="css/jquery.bxslider.css" rel="stylesheet" type="text/css" />
	
<link href="css/common-text.css" rel="stylesheet" type="text/css" />
<link href="css/common-layout.css" rel="stylesheet" type="text/css" />
<link href="css/menu.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="css/resrponsive.css">
<link rel="stylesheet" href="css/jquery.fancybox.min.css" type="text/css" media="screen" />
<link href="css/jquery.bxslider.css" rel="stylesheet" type="text/css" />


</head>

<body>
	
	
	<div class="loader"><span></span></div>
	
    
    <a href="javascript:void(0);" id="Arrowfix" style="display: none;"><span></span></a>
    
	
	
	
	<!--TOPMAIN-->
	<div class="topmain">
		<div class="topmainleft">
			<select name="langues" id="langues">
			  <option value="English">English</option>
			  <option value="Hindi">Hindi</option>
			  <option value="Gujarati">Gujarati</option>
			  <option value="Marathi">Marathi</option>
			</select>
		</div>
		<div class="topmainright">
			<a href="mywhishlist.php">My Wishlist</a> <span>|</span>
			<a href="signin.php">Sign in</a> <span>|</span>
			<a href="register.php">Register</a> <span>|</span>
			<a href="store.php">Store Locator</a> <span>|</span>
			<a href="blog.php">Blog</a>
		</div>
	</div>
	<!--TOPMAIN-->
    
	
	
	<!--TOPMAIN Wrapper-->
	<div class="topmainwrapper">
		<div class="topmaincol1"><a href="index.php"><img src="images/soultatva-logo1.png" alt="" ></a></div>
		<div class="topmaincol2">
			<input type="text" placeholder="Search for products" ><button>Search</button>
		</div>
		<div class="topmaincol3">
			<div class="group clearboth">
				<h6><a href="tel:Call 1300 000 XXX">Call 1300 000 XXX</a></h6>
				<h5><a href="checkout.php">Cart <i class="fa fa-shopping-cart" aria-hidden="true"></i> <span>0</span></a></h5>
			</div>
		</div>
	</div>
	<!--TOPMAIN-->
	
	
	<!--Menu-->
	
	<div class="menubg">
		<nav>
			<a href="#"><i class="fa fa-bars fa-2x"></i></a>
			<ul>
				<li><a href="index.php">Home</a></li>
				<li><a href="about.php">About US</a> <i class="fa fa-caret-down"></i>
					<ul>
						<li><a href="our-story.php">Our Story</a></li>
						<li><a href="eternallypure.php">Eternally Pure</a></li>
						<li><a href="process.php">process</a></li>
					</ul>
				</li>
				<li><a href="products.php">Products</a> <i class="fa fa-caret-down"></i>
					<ul>
						<li><a href="products.php">Products</a></li>
						<li><a href="seed.php">Seed <i class="fa fa-caret-right"></i></a>
							<ul>
								<li><a href="products.php">Seed Name 1</a></li>
								<li><a href="products.php">Seed Name 2</a></li>
								<li><a href="products.php">Seed Name 3</a></li>
							</ul>
						</li>
						<li><a href="nut.php">Nut <i class="fa fa-caret-right"></i></a>
							<ul>
								<li><a href="products.php">Nut Name 1</a></li>
								<li><a href="products.php">Nut Name 2</a></li>
								<li><a href="products.php">Nut Name 3</a></li>
							</ul>
						</li>
						<li><a href="combos.php">Combos <i class="fa fa-caret-right"></i></a>
							<ul>
								<li><a href="products.php">Combos Name 1</a></li>
								<li><a href="products.php">Combos Name 2</a></li>
								<li><a href="products.php">Combos Name 3</a></li>
							</ul>
						</li>
					</ul>
				</li>
				<li><a href="our-pillars.php">Our Pillars</a></li>
				<li><a href="recipes.php">Recipes</a></li>
				<li><a href="blog.php">Blog</a></li>
				<li><a href="contact-us.php">Contact us</a></li>
			</ul>
		</nav>
	</div>
	
	<!--END-->
	
	
	<!--Contain Wrapper-->
	
	<div class="containwrapper">
		
		<div class="bredcum">
			<h1>Eternally Pure</h1>
			<a href="index.php">Home</a> <i class="fa fa-angle-double-right"></i> <span>Eternally Pure</span>
		</div>
		
		
		<div class="ourstorybg">
			<h3>Soultatva-Eternally Pure</h3>
			<h4>Organic Products And Natural Products</h4>
			<p>Whether you’re on a race-track, or running to commute for work; whether you’re lifting heavy weights in a gym, or struggling with the heavy bags of groceries; whether you’re preparing for an important meeting, or studying for a crucial exam- we understand that your body needs energy and care to fight your own battles, every single day. You need zeal, the strength; and not just when doing physically taxing activities, or partaking in sports. Every single moment is important, to you, and to us. We bring to you the foods, which prove to be the first step towards a healthy lifestyle. A source of nutrition, for every action, every activity as per your body’s needs.</p>
			<p>Every time you eat, it is opportunity to nourish your body. However, we often overlook the pleas of our bodies for this nourishment. With Soul Tatva, we look out for your health. We reward you and your soul with the best source of nutrition there is. A wide range of organic and super foods, that boost immunity, strengthen your system, fastens metabolism, and provide the vital nutrients in apt amounts.</p>
			<p>With our products, you would never need to count calories. They’re light, healthy, and right for you. You look and feel as if in your prime. Made with the freshest organic produce, we offer the key to a better life. Soul Tatva brings your body and mind to peace, so you can achieve bigger things in life, feel invincible!</p>
		</div>
		
		
		<!--<div class="group clearboth">
			<div class="aboutbox">
				<div class="bg2">
					<div class="aboutboxtext">
						<h4>Company Overview</h4>
						<p>Ethereal and divine- super food that titillates your taste buds and leaves a lasting, healthy effect on your body. Soul Tatva is the essence, the beauty and the key to your overall well-being. The finest quality amongst organic and super food, it cleanses your body and rejuvenates your senses.</p>
						<p>Your health is your most prized possession, the greatest asset of all. With Soul Tatva, every aspect of your well-being is taken care of. With a vast variety of products to choose from, we cater to all your needs when it comes to leading a healthy lifestyle. With us, you eat right and fresh, and live with vigour.</p>
						<p>We are committed to producing just the best there is to be in your diet, so you could be one with your sagacity. We place products on your platter that please the eye, the tongue, your body, and your soul. Fresh from the farm, rich in nutrients and high on energy, these super foods reinvigorate you, so you can face life with zeal.</p>
					</div>
				</div>
				<div class="imgper"><img src="images/about-pic1.jpg" alt="" ></div>
				<div class="aboutboxtext">
					<h4>Our Vision</h4>
					<p>To be a trustworthy and innovative leader in providing genuine organic True Wellness products and solutions for conscious, healthy living..</p>
				</div>
			</div><div class="aboutbox">
				<div class="imgper"><img src="images/about-pic2.jpg" alt="" ></div>
				<div class="aboutboxtext">
					<h4>The Soul</h4>
					<p>The core, the very essence of your existence, your soul defines who you are and what you will be. Your conscience incarnate, it contains your spirit, your sense of self and the divine chaos within you. We, as humans, rely on making our lives meaningful through the goodness in our hearts and the fire in our souls. This fire, the goodness of your soul is nurtured with good eating. It is satiated when it gets the nourishment it deserves. Embrace it, tame it, cherish it- for it defines how we see ourselves, and how we subsequently act. The soul needs to be treated with tender love and care for it to grow, to bloom. A healthy body is your gateway to a healthy soul. We energize your soul, with nourishment unlike any other; food that not just rejuvenates your body, but also your soul.</p>
				</div>
				<div class="bg2">
					<div class="aboutboxtext">
						<h4>The Tatva</h4>
						<p>The element that is present in everything. The tatva is the building block of the universe; the fundamental foundation that makes life possible. In our case, it is the true elements of food that satiate your soul and make life feasible. Our products are the best in their league and purge you of all that’s holding you back from being in touch with your chakras. Eating healthy doesn’t mean that you ever have to compromise on the taste again. Every bite will harmonize your being; align your mind and senses.</p>
					</div>
				</div>
				
			</div>
		</div>-->
		
		
	</div>
	
	<!--END-->
	
	
	
	
	<!--Footer Wrapper-->
	<div class="footerbg">
		<div class="footerwrapper">
			<div class="group clearboth">
				<div class="footercol1">
					<h6>Quick Links</h6>
					<a href="blog.php">Blog</a>
					<a href="our-story.php">OUR STORY</a>
					<a href="">ETERNALLY PURE</a>
					<a href="">PROCESS</a>
					<a href="">OUR PILLARS</a>
					<a href="">RECIPES</a>
					<a href="">FAQs</a>
				</div>
				<div class="footercol1">
					<h6>PRODUCTS</h6>
					<a href="products.php">SEED</a>
					<a href="products.php">NUT</a>
					<a href="products.php">COMBOS</a>
					<a href="products.php">SPECIAL PACKS</a>
				</div>
				<div class="footercol1">
					<h6>LEGAL</h6>
					<a href="">TERMS &amp; CONDITIONS</a>
					<a href="">PAYMENT POLICY</a>
					<a href="">CONTACT US</a>
				</div>
				<div class="footercol2">
					<h6>Subscribe to our Newsletter</h6>
					<div class="group clearboth footersearch">
						<input type="text" placeholder="Your Email ID" ><button>Search</button>
					</div>
					<hr>
					<div class="imgper"><img src="images/payment.svg" alt="" ></div>
				</div>
			</div>
			<hr>
			<div class="group clearboth">
				<div class="footerbottomleft"> 
					Copyright &copy; 2022 Soultatva. All Right Reserved | Developed By <a href="" target="_blank">Jency Software</a>
				</div>
				<div class="footerbottomright">
					<div class="footersocial">
						<a href="https://www.facebook.com/Soultatva" target="_blank"><i class="fab fa-facebook"></i></a>
                        <a href="https://www.linkedin.com/showcase/soul-tatva" target="_blank"><i class="fab fa-linkedin"></i></a>
                        <a href="https://twitter.com/SoulTatva" target="_blank"><i class="fab fa-twitter"></i></a>
                        <a href="https://www.instagram.com/soultatva/" target="_blank"><i class="fab fa-instagram"></i></a>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!--END-->
	
	
	
    
 

<script type="text/javascript" src="js/jquery-3.3.1.min.js"></script>
<script type="text/javascript" src="js/ajax-1.9.0.min.js"></script>

<script type="text/javascript">
	$(document).ready(function(){
		$(window).scroll(function(){
			if ($(this).scrollTop() > 50) {
				$('#Arrowfix').fadeIn();
			} else {
				$('#Arrowfix').fadeOut();
			}
		});
		$('#Arrowfix').click(function(){
			$("html, body").animate({ scrollTop: 0 }, 400);
			return false;
		});
	});
</script>
	
<script type="text/javascript">
	var list = $("nav>ul li > a");
	$("nav > a").click(function (event) {
		$("nav>ul").slideToggle();
	});
	list.click(function (event) {
		var submenu = this.parentNode.getElementsByTagName("ul").item(0);
		if (submenu != null) {
			event.preventDefault();
			//$(submenu).slideToggle();
		}
	});
		$(window).resize(function () {
			if ($(window).width() > 1180) {
				$("nav > ul, nav > ul  li  ul").removeAttr("style");
			}
		});
		$(".scroll").click(function (event) { 
			if ($(window).width() < 1180) {
			$("nav>ul").slideToggle();
		}
	 });
</script>	

<script src="js/jquery.balance.js" type="text/javascript"></script>
<script type="text/javascript">
	$(window).load(function() {
		$('.trandingheight').balance() ;
		$('.assetsboxheight').balance() ;
		$('.idxvideoheight').balance() ;
	});
</script>
	
	
<script src="js/jquery.bxslider.js" type="text/javascript"></script>	
<script type="text/javascript">
	
	$(document).ready(function(){
	  if($(window).width() < 30500){
		  $('.headerslider').bxSlider({
			infiniteLoop:true,
			auto:true,
			pager:false,
			controls:true,
			  oneToOneTouch:true,
				pause: 8000,
				touchEnabled: true,
		 });
	  }
	});
	
	$(document).ready(function(){
	  if($(window).width() < 30500){
		  $('.bannerslider').bxSlider({
			infiniteLoop:true,
			auto:true,
			pager:false,
			controls:false,
			  oneToOneTouch:true,
				pause: 8000,
				touchEnabled: true,
		 });
	  }
	});
	
	
	$(document).ready(function(){
		if($(window).width()>1500){
			$('.assetsslide').bxSlider({
				infiniteLoop:true,
				auto:false,
				slideWidth: 370,
				maxSlides: 4,
				pager:false,
				controls:true,
				oneToOneTouch:false,
				pause: 10000,
				touchEnabled: true,
				moveSlides:1,
				 preventDefaultSwipeX:true,
				preventDefaultSwipeY:true
			});
		}
	   
		else{
		if($(window).width()<=1500 && $(window).width() > 1280) {			
			$('.assetsslide').bxSlider({
				slideWidth: 290,
				auto:false,
				maxSlides: 4,
				moveSlides:1,
				pager:false,
				controls:true,
				autoHover: true,
				oneToOneTouch:false,
				pause: 10000,
				touchEnabled: true
			});
		}
		
		else{
		if($(window).width()<=1280 && $(window).width() > 800) {			
			$('.assetsslide').bxSlider({
				slideWidth: 300,
				auto:false,
				maxSlides: 4,
				moveSlides:1,
				pager:false,
				controls:true,
				autoHover: true,
				oneToOneTouch:false,
				pause: 10000,
				touchEnabled: true
			});
		}
		
		else if($(window).width()<=800) {
			$('.assetsslide').bxSlider({
				slideWidth: 400,
				maxSlides: 1
				,pager:false,
				controls:true,
				autoHover: true,
				oneToOneTouch:false,
				pause: 10000,
				touchEnabled: true
			});
		}	   
	   }
			}
	});
	
</script>
	
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.2/jquery.fancybox.min.js"></script>
<script type="text/javascript">
	
	$(document).ready(function() {
		$("data-fancybox").fancybox();
	});
	$(document).ready(function() {
		$(".fancybox").fancybox();
	});
</script>
	
	
<script type="text/javascript">
	$(window).load(function() {
		$(".loader").fadeOut("slow");
	})
</script>	

</body>
</html>
