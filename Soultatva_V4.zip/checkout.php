<html lang="en">
<head>
<title>Buy Organic Seeds, Dry Fruits &amp; Nuts from Soultatva</title>

<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0, minimal-ui" />


<link rel="icon" type="image/png" href="favicon.png">
<link rel="shortcut icon" href="favicon.ico">


<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Nunito:ital,wght@0,200;0,300;0,400;0,600;0,700;0,800;0,900;1,200;1,300;1,400;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">



<link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">



<link href="css/jquery.bxslider.css" rel="stylesheet" type="text/css" />
	
<link href="css/common-text.css" rel="stylesheet" type="text/css" />
<link href="css/common-layout.css" rel="stylesheet" type="text/css" />
<link href="css/menu.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="css/resrponsive.css">
<link rel="stylesheet" href="css/jquery.fancybox.min.css" type="text/css" media="screen" />
<link href="css/jquery.bxslider.css" rel="stylesheet" type="text/css" />


</head>

<body>
	
    
	<div class="loader"><span></span></div>
	
    <a href="javascript:void(0);" id="Arrowfix" style="display: none;"><span></span></a>
    
	
	
	
	<!--TOPMAIN-->
	<div class="topmain">
		<div class="topmainleft">
			<select name="langues" id="langues">
			  <option value="English">English</option>
			  <option value="Hindi">Hindi</option>
			  <option value="Gujarati">Gujarati</option>
			  <option value="Marathi">Marathi</option>
			</select>
		</div>
		<div class="topmainright">
			<a href="mywhishlist.php">My Wishlist</a> <span>|</span>
			<a href="signin.php">Sign in</a> <span>|</span>
			<a href="register.php">Register</a> <span>|</span>
			<a href="store.php">Store Locator</a> <span>|</span>
			<a href="blog.php">Blog</a>
		</div>
	</div>
	<!--TOPMAIN-->
    
	
	
	<!--TOPMAIN Wrapper-->
	<div class="topmainwrapper">
		<div class="topmaincol1"><a href="index.php"><img src="images/soultatva-logo1.png" alt="" ></a></div>
		<div class="topmaincol2">
			<input type="text" placeholder="Search for products" ><button>Search</button>
		</div>
		<div class="topmaincol3">
			<div class="group clearboth">
				<h6><a href="tel:Call 1300 000 XXX">Call 1300 000 XXX</a></h6>
				<h5><a href="checkout.php">Cart <i class="fa fa-shopping-cart" aria-hidden="true"></i> <span>0</span></a></h5>
			</div>
		</div>
	</div>
	<!--TOPMAIN-->
	
	
	<!--Menu-->
	
	<div class="menubg">
		<nav>
			<a href="#"><i class="fa fa-bars fa-2x"></i></a>
			<ul>
				<li><a href="index.php">Home</a></li>
				<li><a href="about.php">About US</a> <i class="fa fa-caret-down"></i>
					<ul>
						<li><a href="our-story.php">Our Story</a></li>
						<li><a href="eternallypure.php">Eternally Pure</a></li>
						<li><a href="process.php">process</a></li>
					</ul>
				</li>
				<li><a href="products.php">Products</a> <i class="fa fa-caret-down"></i>
					<ul>
						<li><a href="products.php">Products</a></li>
						<li><a href="seed.php">Seed <i class="fa fa-caret-right"></i></a>
							<ul>
								<li><a href="products.php">Seed Name 1</a></li>
								<li><a href="products.php">Seed Name 2</a></li>
								<li><a href="products.php">Seed Name 3</a></li>
							</ul>
						</li>
						<li><a href="nut.php">Nut <i class="fa fa-caret-right"></i></a>
							<ul>
								<li><a href="products.php">Nut Name 1</a></li>
								<li><a href="products.php">Nut Name 2</a></li>
								<li><a href="products.php">Nut Name 3</a></li>
							</ul>
						</li>
						<li><a href="combos.php">Combos <i class="fa fa-caret-right"></i></a>
							<ul>
								<li><a href="products.php">Combos Name 1</a></li>
								<li><a href="products.php">Combos Name 2</a></li>
								<li><a href="products.php">Combos Name 3</a></li>
							</ul>
						</li>
					</ul>
				</li>
				<li><a href="our-pillars.php">Our Pillars</a></li>
				<li><a href="recipes">Recipes</a></li>
				<li><a href="blog.php">Blog</a></li>
				<li><a href="contact-us.php">Contact us</a></li>
			</ul>
		</nav>
	</div>
	
	<!--END-->
	
	
	<!--Contain Wrapper-->
	
	<div class="containwrapper">
		
		<div class="bredcum">
			<h1>Your Shopping Cart</h1>
			<a href="index.php">Home</a> <i class="fa fa-angle-double-right"></i> <span>Checkout</span>
		</div>
		
		<p>You are checking out as a guest,<br>Have an account? <a href="signin.php">Sing in</a></p>
		
		
		<div class="group clearboth">
		 	<div class="checkoutmainleft">
				<div class="checkoutleftbox">
					<h3>Billing Address <a class="showsingle" target="1">Edit</a></h3>
					<div id="leftmenu1" class="checkaddressbox" style="display: block;">
						<p>We use this information to register products,<br>secure your identity and calculate taxes and fees.</p>
						
						<div class="formbox2">
							<label>Country / Region*</label>
                            <select id="country" name="country">
                                <option value="India">India</option>
                                <option value="Afghanistan">Afghanistan</option>
                                <option value="Albania">Albania</option>
                                <option value="Algeria">Algeria</option>
                                <option value="American Samoa">American Samoa</option>
                                <option value="Andorra">Andorra</option>
                                <option value="Angola">Angola</option>
                                <option value="Antigua and Barbuda">Antigua and Barbuda</option>
                                <option value="Argentina">Argentina</option>
                                <option value="Armenia">Armenia</option>
                                <option value="Australia">Australia</option>
                                <option value="Austria">Austria</option>
                                <option value="Azerbaijan">Azerbaijan</option>
                                <option value="Bahamas">Bahamas</option>
                                <option value="Bahrain">Bahrain</option>
                                <option value="Bangladesh">Bangladesh</option>
                                <option value="Barbados">Barbados</option>
                                <option value="Belarus">Belarus</option>
                                <option value="Belgium">Belgium</option>
                                <option value="Belize">Belize</option>
                                <option value="Benin">Benin</option>
                                <option value="Bermuda">Bermuda</option>
                                <option value="Bhutan">Bhutan</option>
                                <option value="Bolivia">Bolivia</option>
                                <option value="Bosnia and Herzegovina">Bosnia and Herzegovina</option>
                                <option value="Botswana">Botswana</option>
                                <option value="Brazil">Brazil</option>
                                <option value="Brunei">Brunei</option>
                                <option value="Bulgaria">Bulgaria</option>
                                <option value="Burkina Faso">Burkina Faso</option>
                                <option value="Burundi">Burundi</option>
                                <option value="Cambodia">Cambodia</option>
                                <option value="Cameroon">Cameroon</option>
                                <option value="Canada">Canada</option>
                                <option value="Cape Verde">Cape Verde</option>
                                <option value="Cayman Islands">Cayman Islands</option>
                                <option value="Central African Republic">Central African Republic</option>
                                <option value="Chad">Chad</option>
                                <option value="Chile">Chile</option>
                                <option value="China">China</option>
                                <option value="Colombia">Colombia</option>
                                <option value="Comoros">Comoros</option>
                                <option value="Congo, Democratic Republic of the">Congo, Democratic Republic of the</option>
                                <option value="Congo, Republic of the">Congo, Republic of the</option>
                                <option value="Costa Rica">Costa Rica</option>
                                <option value="Côte d&#039;Ivoire">Côte d&#039;Ivoire</option>
                                <option value="Croatia">Croatia</option>
                                <option value="Cuba">Cuba</option>
                                <option value="Cyprus">Cyprus</option>
                                <option value="Czech Republic">Czech Republic</option>
                                <option value="Denmark">Denmark</option>
                                <option value="Djibouti">Djibouti</option>
                                <option value="Dominica">Dominica</option>
                                <option value="Dominican Republic">Dominican Republic</option>
                                <option value="East Timor">East Timor</option>
                                <option value="Ecuador">Ecuador</option>
                                <option value="Egypt">Egypt</option>
                                <option value="El Salvador">El Salvador</option>
                                <option value="Equatorial Guinea">Equatorial Guinea</option>
                                <option value="Eritrea">Eritrea</option>
                                <option value="Estonia">Estonia</option>
                                <option value="Ethiopia">Ethiopia</option>
                                <option value="Fiji">Fiji</option>
                                <option value="Finland">Finland</option>
                                <option value="France">France</option>
                                <option value="Gabon">Gabon</option>
                                <option value="Gambia">Gambia</option>
                                <option value="Georgia">Georgia</option>
                                <option value="Germany">Germany</option>
                                <option value="Ghana">Ghana</option>
                                <option value="Greece">Greece</option>
                                <option value="Greenland">Greenland</option>
                                <option value="Grenada">Grenada</option>
                                <option value="Guam">Guam</option>
                                <option value="Guatemala">Guatemala</option>
                                <option value="Guinea">Guinea</option>
                                <option value="Guinea-Bissau">Guinea-Bissau</option>
                                <option value="Guyana">Guyana</option>
                                <option value="Haiti">Haiti</option>
                                <option value="Honduras">Honduras</option>
                                <option value="Hong Kong">Hong Kong</option>
                                <option value="Hungary">Hungary</option>
                                <option value="Iceland">Iceland</option>
                                <option value="Indonesia">Indonesia</option>
                                <option value="Iran">Iran</option>
                                <option value="Iraq">Iraq</option> 
                                <option value="Ireland">Ireland</option>
                                <option value="Israel">Israel</option>
                                <option value="Italy">Italy</option>
                                <option value="Jamaica">Jamaica</option>
                                <!-- <option value="Japan">Japan</option> -->
                                <option value="Jordan">Jordan</option>
                                <option value="Kazakhstan">Kazakhstan</option>
                                <option value="Kenya">Kenya</option>
                                <option value="Kiribati">Kiribati</option>
                                <!-- <option value="North Korea">North Korea</option>-->
                                <option value="South Korea">South Korea</option> 
                                <option value="Kuwait">Kuwait</option>
                                <option value="Kyrgyzstan">Kyrgyzstan</option>
                                <option value="Laos">Laos</option>
                                <option value="Latvia">Latvia</option>
                                <option value="Lebanon">Lebanon</option>
                                <option value="Lesotho">Lesotho</option>
                                <option value="Liberia">Liberia</option>
                                <option value="Libya">Libya</option>
                                <option value="Liechtenstein">Liechtenstein</option>
                                <option value="Lithuania">Lithuania</option>
                                <option value="Luxembourg">Luxembourg</option>
                                <option value="Macedonia">Macedonia</option>
                                <option value="Madagascar">Madagascar</option>
                                <option value="Malawi">Malawi</option>
                                <option value="Malaysia">Malaysia</option>
                                <option value="Maldives">Maldives</option>
                                <option value="Mali">Mali</option>
                                <option value="Malta">Malta</option>
                                <option value="Marshall Islands">Marshall Islands</option>
                                <option value="Mauritania">Mauritania</option>
                                <option value="Mauritius">Mauritius</option>
                                <option value="Mexico">Mexico</option>
                                <option value="Micronesia">Micronesia</option>
                                <option value="Moldova">Moldova</option>
                                <option value="Monaco">Monaco</option>
                                <option value="Mongolia">Mongolia</option>
                                <option value="Montenegro">Montenegro</option>
                                <option value="Morocco">Morocco</option>
                                <option value="Mozambique">Mozambique</option>
                                <option value="Myanmar">Myanmar</option>
                                <option value="Namibia">Namibia</option>
                                <option value="Nauru">Nauru</option>
                                <option value="Nepal">Nepal</option>
                                <option value="Netherlands">Netherlands</option>
                                <option value="New Zealand">New Zealand</option>
                                <option value="Nicaragua">Nicaragua</option>
                                <option value="Niger">Niger</option>
                                <option value="Nigeria">Nigeria</option>
                                <option value="Norway">Norway</option>
                                <option value="Northern Mariana Islands">Northern Mariana Islands</option>
                                <option value="Oman">Oman</option>
                                <option value="Pakistan">Pakistan</option>
                                <option value="Palau">Palau</option>
                                <option value="Palestine">Palestine</option>
                                <option value="Panama">Panama</option>
                                <option value="Papua New Guinea">Papua New Guinea</option>
                                <option value="Paraguay">Paraguay</option>
                                <option value="Peru">Peru</option>
                                <!-- <option value="Philippines">Philippines</option> -->
                                <option value="Poland">Poland</option>
                                <option value="Portugal">Portugal</option>
                                <option value="Puerto Rico">Puerto Rico</option>
                                <option value="Qatar">Qatar</option>
                                <option value="Romania">Romania</option>
                                <!-- <option value="Russia">Russia</option> -->
                                <option value="Rwanda">Rwanda</option>
                                <option value="Saint Kitts and Nevis">Saint Kitts and Nevis</option>
                                <option value="Saint Lucia">Saint Lucia</option>
                                <option value="Saint Vincent and the Grenadines">Saint Vincent and the Grenadines</option>
                                <option value="Samoa">Samoa</option>
                                <option value="San Marino">San Marino</option>
                                <option value="Sao Tome and Principe">Sao Tome and Principe</option>
                                <option value="Saudi Arabia">Saudi Arabia</option>
                                <option value="Senegal">Senegal</option>
                                <option value="Serbia and Montenegro">Serbia and Montenegro</option>
                                <option value="Seychelles">Seychelles</option>
                                <option value="Sierra Leone">Sierra Leone</option>
                                <option value="Singapore">Singapore</option>
                                <option value="Slovakia">Slovakia</option>
                                <option value="Slovenia">Slovenia</option>
                                <option value="Solomon Islands">Solomon Islands</option>
                                <option value="Somalia">Somalia</option>
                                <option value="South Africa">South Africa</option>
                                <option value="Spain">Spain</option>
                                <option value="Sri Lanka">Sri Lanka</option>
                                <option value="Sudan">Sudan</option>
                                <option value="Sudan, South">Sudan, South</option> 
                                <option value="Suriname">Suriname</option>
                                <option value="Swaziland">Swaziland</option>
                                <option value="Sweden">Sweden</option>
                                <option value="Switzerland">Switzerland</option>
                                <!-- <option value="Syria">Syria</option> -->
                                <option value="Taiwan">Taiwan</option>
                                <option value="Tajikistan">Tajikistan</option>
                                <option value="Tanzania">Tanzania</option>
                                <option value="Thailand">Thailand</option>
                                <option value="Togo">Togo</option>
                                <option value="Tonga">Tonga</option>
                                <option value="Trinidad and Tobago">Trinidad and Tobago</option>
                                <option value="Tunisia">Tunisia</option>
                                <!-- <option value="Turkey">Turkey</option> -->
                                <option value="Turkmenistan">Turkmenistan</option>
                                <option value="Tuvalu">Tuvalu</option>
                                <option value="Uganda">Uganda</option>
                                <option value="Ukraine">Ukraine</option>
                                <option value="United Arab Emirates">United Arab Emirates</option>
                                <option value="United Kingdom">United Kingdom</option>
                                <option value="United States">United States</option>
                                <option value="Uruguay">Uruguay</option>
                                <option value="Uzbekistan">Uzbekistan</option>
                                <option value="Vanuatu">Vanuatu</option>
                                <option value="Vatican City">Vatican City</option>
                                <option value="Venezuela">Venezuela</option>
                                <option value="Vietnam">Vietnam</option>
                                <option value="Virgin Islands, British">Virgin Islands, British</option>
                                <option value="Virgin Islands, U.S.">Virgin Islands, U.S.</option>
                                <option value="Yemen">Yemen</option>
                                <option value="Zambia">Zambia</option>
                                <option value="Zimbabwe">Zimbabwe</option>
                            </select>
						</div>
						<div class="formbox2">
							<label>Your name</label>
							<input type="text"  name="name" id="name" value="" required>
						</div>
						<div class="formbox2">
							<label>Building / Society*</label>
							<input type="text"  name="name" id="" value="" required>
						</div>
						<div class="formbox2">
							<label>Street Name / Landmark</label>
							<input type="text"  name="name" id="" value="" required>
						</div>
						<div class="formbox2">
							<label>Postal Code*</label>
							<input type="text"  name="name" id="" value="" required>
						</div>
						<div class="formbox2">
							<label>State*</label>
							<input type="text"  name="name" id="" value="" required>
						</div>
						<div class="formbox2">
							<label>City*</label>
							<input type="text"  name="name" id="" value="" required>
						</div>
						<div class="formbox2">
							<label>Your Email Address</label>
							<input type="text"  name="email" id="email" value="" required>
						</div>
						<div class="formbox2">
							<label>Mobile phone number</label>
							<input type="text"  name="mobile" id="mobile" value="" required>
						</div>
						<div class="formbox2">
							<button type="submit" id="submit" name="submit" class="button">Save</button>
						</div>
						
					</div>
				</div>
				<div class="checkoutleftbox">
					<h3>Shipping Address <a class="showsingle" target="2">Edit</a></h3>
					<div id="leftmenu2" class="checkaddressbox">
						<p>We use this information to register products,<br>secure your identity and calculate taxes and fees.</p>
						
						<div class="formbox2">
							<label>Country / Region*</label>
                            <select id="country" name="country">
                                <option value="India">India</option>
                                <option value="Afghanistan">Afghanistan</option>
                                <option value="Albania">Albania</option>
                                <option value="Algeria">Algeria</option>
                                <option value="American Samoa">American Samoa</option>
                                <option value="Andorra">Andorra</option>
                                <option value="Angola">Angola</option>
                                <option value="Antigua and Barbuda">Antigua and Barbuda</option>
                                <option value="Argentina">Argentina</option>
                                <option value="Armenia">Armenia</option>
                                <option value="Australia">Australia</option>
                                <option value="Austria">Austria</option>
                                <option value="Azerbaijan">Azerbaijan</option>
                                <option value="Bahamas">Bahamas</option>
                                <option value="Bahrain">Bahrain</option>
                                <option value="Bangladesh">Bangladesh</option>
                                <option value="Barbados">Barbados</option>
                                <option value="Belarus">Belarus</option>
                                <option value="Belgium">Belgium</option>
                                <option value="Belize">Belize</option>
                                <option value="Benin">Benin</option>
                                <option value="Bermuda">Bermuda</option>
                                <option value="Bhutan">Bhutan</option>
                                <option value="Bolivia">Bolivia</option>
                                <option value="Bosnia and Herzegovina">Bosnia and Herzegovina</option>
                                <option value="Botswana">Botswana</option>
                                <option value="Brazil">Brazil</option>
                                <option value="Brunei">Brunei</option>
                                <option value="Bulgaria">Bulgaria</option>
                                <option value="Burkina Faso">Burkina Faso</option>
                                <option value="Burundi">Burundi</option>
                                <option value="Cambodia">Cambodia</option>
                                <option value="Cameroon">Cameroon</option>
                                <option value="Canada">Canada</option>
                                <option value="Cape Verde">Cape Verde</option>
                                <option value="Cayman Islands">Cayman Islands</option>
                                <option value="Central African Republic">Central African Republic</option>
                                <option value="Chad">Chad</option>
                                <option value="Chile">Chile</option>
                                <option value="China">China</option>
                                <option value="Colombia">Colombia</option>
                                <option value="Comoros">Comoros</option>
                                <option value="Congo, Democratic Republic of the">Congo, Democratic Republic of the</option>
                                <option value="Congo, Republic of the">Congo, Republic of the</option>
                                <option value="Costa Rica">Costa Rica</option>
                                <option value="Côte d&#039;Ivoire">Côte d&#039;Ivoire</option>
                                <option value="Croatia">Croatia</option>
                                <option value="Cuba">Cuba</option>
                                <option value="Cyprus">Cyprus</option>
                                <option value="Czech Republic">Czech Republic</option>
                                <option value="Denmark">Denmark</option>
                                <option value="Djibouti">Djibouti</option>
                                <option value="Dominica">Dominica</option>
                                <option value="Dominican Republic">Dominican Republic</option>
                                <option value="East Timor">East Timor</option>
                                <option value="Ecuador">Ecuador</option>
                                <option value="Egypt">Egypt</option>
                                <option value="El Salvador">El Salvador</option>
                                <option value="Equatorial Guinea">Equatorial Guinea</option>
                                <option value="Eritrea">Eritrea</option>
                                <option value="Estonia">Estonia</option>
                                <option value="Ethiopia">Ethiopia</option>
                                <option value="Fiji">Fiji</option>
                                <option value="Finland">Finland</option>
                                <option value="France">France</option>
                                <option value="Gabon">Gabon</option>
                                <option value="Gambia">Gambia</option>
                                <option value="Georgia">Georgia</option>
                                <option value="Germany">Germany</option>
                                <option value="Ghana">Ghana</option>
                                <option value="Greece">Greece</option>
                                <option value="Greenland">Greenland</option>
                                <option value="Grenada">Grenada</option>
                                <option value="Guam">Guam</option>
                                <option value="Guatemala">Guatemala</option>
                                <option value="Guinea">Guinea</option>
                                <option value="Guinea-Bissau">Guinea-Bissau</option>
                                <option value="Guyana">Guyana</option>
                                <option value="Haiti">Haiti</option>
                                <option value="Honduras">Honduras</option>
                                <option value="Hong Kong">Hong Kong</option>
                                <option value="Hungary">Hungary</option>
                                <option value="Iceland">Iceland</option>
                                <option value="Indonesia">Indonesia</option>
                                <option value="Iran">Iran</option>
                                <option value="Iraq">Iraq</option> 
                                <option value="Ireland">Ireland</option>
                                <option value="Israel">Israel</option>
                                <option value="Italy">Italy</option>
                                <option value="Jamaica">Jamaica</option>
                                <!-- <option value="Japan">Japan</option> -->
                                <option value="Jordan">Jordan</option>
                                <option value="Kazakhstan">Kazakhstan</option>
                                <option value="Kenya">Kenya</option>
                                <option value="Kiribati">Kiribati</option>
                                <!-- <option value="North Korea">North Korea</option>-->
                                <option value="South Korea">South Korea</option> 
                                <option value="Kuwait">Kuwait</option>
                                <option value="Kyrgyzstan">Kyrgyzstan</option>
                                <option value="Laos">Laos</option>
                                <option value="Latvia">Latvia</option>
                                <option value="Lebanon">Lebanon</option>
                                <option value="Lesotho">Lesotho</option>
                                <option value="Liberia">Liberia</option>
                                <option value="Libya">Libya</option>
                                <option value="Liechtenstein">Liechtenstein</option>
                                <option value="Lithuania">Lithuania</option>
                                <option value="Luxembourg">Luxembourg</option>
                                <option value="Macedonia">Macedonia</option>
                                <option value="Madagascar">Madagascar</option>
                                <option value="Malawi">Malawi</option>
                                <option value="Malaysia">Malaysia</option>
                                <option value="Maldives">Maldives</option>
                                <option value="Mali">Mali</option>
                                <option value="Malta">Malta</option>
                                <option value="Marshall Islands">Marshall Islands</option>
                                <option value="Mauritania">Mauritania</option>
                                <option value="Mauritius">Mauritius</option>
                                <option value="Mexico">Mexico</option>
                                <option value="Micronesia">Micronesia</option>
                                <option value="Moldova">Moldova</option>
                                <option value="Monaco">Monaco</option>
                                <option value="Mongolia">Mongolia</option>
                                <option value="Montenegro">Montenegro</option>
                                <option value="Morocco">Morocco</option>
                                <option value="Mozambique">Mozambique</option>
                                <option value="Myanmar">Myanmar</option>
                                <option value="Namibia">Namibia</option>
                                <option value="Nauru">Nauru</option>
                                <option value="Nepal">Nepal</option>
                                <option value="Netherlands">Netherlands</option>
                                <option value="New Zealand">New Zealand</option>
                                <option value="Nicaragua">Nicaragua</option>
                                <option value="Niger">Niger</option>
                                <option value="Nigeria">Nigeria</option>
                                <option value="Norway">Norway</option>
                                <option value="Northern Mariana Islands">Northern Mariana Islands</option>
                                <option value="Oman">Oman</option>
                                <option value="Pakistan">Pakistan</option>
                                <option value="Palau">Palau</option>
                                <option value="Palestine">Palestine</option>
                                <option value="Panama">Panama</option>
                                <option value="Papua New Guinea">Papua New Guinea</option>
                                <option value="Paraguay">Paraguay</option>
                                <option value="Peru">Peru</option>
                                <!-- <option value="Philippines">Philippines</option> -->
                                <option value="Poland">Poland</option>
                                <option value="Portugal">Portugal</option>
                                <option value="Puerto Rico">Puerto Rico</option>
                                <option value="Qatar">Qatar</option>
                                <option value="Romania">Romania</option>
                                <!-- <option value="Russia">Russia</option> -->
                                <option value="Rwanda">Rwanda</option>
                                <option value="Saint Kitts and Nevis">Saint Kitts and Nevis</option>
                                <option value="Saint Lucia">Saint Lucia</option>
                                <option value="Saint Vincent and the Grenadines">Saint Vincent and the Grenadines</option>
                                <option value="Samoa">Samoa</option>
                                <option value="San Marino">San Marino</option>
                                <option value="Sao Tome and Principe">Sao Tome and Principe</option>
                                <option value="Saudi Arabia">Saudi Arabia</option>
                                <option value="Senegal">Senegal</option>
                                <option value="Serbia and Montenegro">Serbia and Montenegro</option>
                                <option value="Seychelles">Seychelles</option>
                                <option value="Sierra Leone">Sierra Leone</option>
                                <option value="Singapore">Singapore</option>
                                <option value="Slovakia">Slovakia</option>
                                <option value="Slovenia">Slovenia</option>
                                <option value="Solomon Islands">Solomon Islands</option>
                                <option value="Somalia">Somalia</option>
                                <option value="South Africa">South Africa</option>
                                <option value="Spain">Spain</option>
                                <option value="Sri Lanka">Sri Lanka</option>
                                <option value="Sudan">Sudan</option>
                                <option value="Sudan, South">Sudan, South</option> 
                                <option value="Suriname">Suriname</option>
                                <option value="Swaziland">Swaziland</option>
                                <option value="Sweden">Sweden</option>
                                <option value="Switzerland">Switzerland</option>
                                <!-- <option value="Syria">Syria</option> -->
                                <option value="Taiwan">Taiwan</option>
                                <option value="Tajikistan">Tajikistan</option>
                                <option value="Tanzania">Tanzania</option>
                                <option value="Thailand">Thailand</option>
                                <option value="Togo">Togo</option>
                                <option value="Tonga">Tonga</option>
                                <option value="Trinidad and Tobago">Trinidad and Tobago</option>
                                <option value="Tunisia">Tunisia</option>
                                <!-- <option value="Turkey">Turkey</option> -->
                                <option value="Turkmenistan">Turkmenistan</option>
                                <option value="Tuvalu">Tuvalu</option>
                                <option value="Uganda">Uganda</option>
                                <option value="Ukraine">Ukraine</option>
                                <option value="United Arab Emirates">United Arab Emirates</option>
                                <option value="United Kingdom">United Kingdom</option>
                                <option value="United States">United States</option>
                                <option value="Uruguay">Uruguay</option>
                                <option value="Uzbekistan">Uzbekistan</option>
                                <option value="Vanuatu">Vanuatu</option>
                                <option value="Vatican City">Vatican City</option>
                                <option value="Venezuela">Venezuela</option>
                                <option value="Vietnam">Vietnam</option>
                                <option value="Virgin Islands, British">Virgin Islands, British</option>
                                <option value="Virgin Islands, U.S.">Virgin Islands, U.S.</option>
                                <option value="Yemen">Yemen</option>
                                <option value="Zambia">Zambia</option>
                                <option value="Zimbabwe">Zimbabwe</option>
                            </select>
						</div>
						<div class="formbox2">
							<label>Your name</label>
							<input type="text"  name="name" id="name" value="" required>
						</div>
						<div class="formbox2">
							<label>Building / Society*</label>
							<input type="text"  name="name" id="" value="" required>
						</div>
						<div class="formbox2">
							<label>Street Name / Landmark</label>
							<input type="text"  name="name" id="" value="" required>
						</div>
						<div class="formbox2">
							<label>Postal Code*</label>
							<input type="text"  name="name" id="" value="" required>
						</div>
						<div class="formbox2">
							<label>State*</label>
							<input type="text"  name="name" id="" value="" required>
						</div>
						<div class="formbox2">
							<label>City*</label>
							<input type="text"  name="name" id="" value="" required>
						</div>
						<div class="formbox2">
							<label>Your Email Address</label>
							<input type="text"  name="email" id="email" value="" required>
						</div>
						<div class="formbox2">
							<label>Mobile phone number</label>
							<input type="text"  name="mobile" id="mobile" value="" required>
						</div>
						<div class="formbox2">
							<button type="submit" id="submit" name="submit" class="button">Save</button>
						</div>
						
					</div>
				</div>
				<div class="checkoutleftbox">
					<h3>Shipping Method <a class="showsingle" target="3">Edit</a></h3>
					<div id="leftmenu3" class="checkaddressbox">
						
						<div class="formbox3">
							<input type="radio" name="ship_method" id="method1" > <label for="method1">FedEX Next Day Delivery <span>₹200</span></label>
						</div>
						<div class="formbox3">
							<input type="radio" name="ship_method" id="method2" > <label for="method2">DHL Express <span>₹150</span></label>
						</div>
						<div class="formbox3">
							<input type="radio" name="ship_method" id="method3" > <label for="method3">FedEX Next Day Delivery <span>₹100</span></label>
						</div>
						
						
						<div class="formbox2">
							<button type="submit" id="submit" name="submit" class="button">Continue</button>
						</div>
						
					</div>
				</div>
				<div class="checkoutleftbox">
					<h3>Payment <a class="showsingle" target="4">Edit</a></h3>
					<div id="leftmenu4" class="checkaddressbox">
						
						<div class="checkpromo">
							<input type="text"  placeholder="Promo code" ><button type="button" >Apply</button>
						</div>
						
						<p class="mtb1"><a href="#">What is this</a></p>
						
						
						<div class="checkcardimg">
							<a href="#"><img src="images/card1.jpg" alt="" ></a>
							<a href="#"><img src="images/upi.jpg" alt="" ></a>
							<a href="#"><img src="images/internet.jpg" alt="" ></a>
						</div>
						
						<div class="checkcardbox">
							<h4>Card</h4>
							<div class="formbox1">
								<input type="number"  name="number" value="" placeholder="Card Number" required>
							</div>
							<div class="formbox1 checkmoye">
								<input type="number"  name="number" value="" placeholder="Month" required>
								<input type="number"  name="number" value="" placeholder="Year" required>
							</div>
							<div class="formbox1">
								<input type="number"  name="number" value="" placeholder="Security Code" required>
							</div>
							<div class="formbox2"><button type="submit" id="submit" name="submit" class="button">Continue</button></div>
							
							
						</div>
						
						
					</div>
				</div>
			</div>
			<div class="checkoutmainright">
				<div class="checkoutrightbox">
					<h4>Order Summery</h4>
					<div class="checkoutrightbox1">
						<div class="checkoutrightbox1col1"><img src="images/product-detail1.jpg" alt="" ></div>
						<div class="checkoutrightbox1col2">
							<h6>Sunflower Seeds Roasted Salted</h6>
							<p>Qty 1</p>
							<div class="btn1"><a href="products-detail.php">More Details</a></div>
						</div>
						<div class="checkoutrightbox1col3">
							<p>OTY: 1</p>
							<h6>Price: ₹900</h6>
							<div class="btn1"><a href="#"><i class="fa fa-edit"></i></a> <a href="#"><i class="fa fa-trash"></i></a></div>
						</div>
					</div>
					<div class="checkoutrightbox1">
						<div class="checkoutrightbox1col1"><img src="images/product-detail1.jpg" alt="" ></div>
						<div class="checkoutrightbox1col2">
							<h6>Sunflower Seeds Roasted Salted</h6>
							<p>Qty 1</p>
							<div class="btn1"><a href="products-detail.php">More Details</a></div>
						</div>
						<div class="checkoutrightbox1col3">
							<p>OTY: 1</p>
							<h6>Price: ₹900</h6>
							<div class="btn1"><a href="#"><i class="fa fa-edit"></i></a> <a href="#"><i class="fa fa-trash"></i></a></div>
						</div>
					</div>
					<div class="checkoutrightbox1">
						<div class="checkoutrightbox1col1"><img src="images/product-detail1.jpg" alt="" ></div>
						<div class="checkoutrightbox1col2">
							<h6>Sunflower Seeds Roasted Salted</h6>
							<p>Qty 1</p>
							<div class="btn1"><a href="products-detail.php">More Details</a></div>
						</div>
						<div class="checkoutrightbox1col3">
							<p>OTY: 1</p>
							<h6>Price: ₹900</h6>
							<div class="btn1"><a href="#"><i class="fa fa-edit"></i></a> <a href="#"><i class="fa fa-trash"></i></a></div>
						</div>
					</div>
					<div class="checkoutsubtotal">
						<h6>Subtotal <span>₹599</span></h6>
						<h6>Discount <span>₹10</span></h6>
						<h6>Shipping <span>₹50</span></h6>
						<h6>Tax  <span>₹50</span></h6>
						<hr>
						<h5>Order Total <span>₹700</span></h5>
					</div>
				</div>
				
				<p class="tac mtb2"><a href="#">Save for later</a></p>
				
				<div class="formbox2"><button type="submit" id="submit" name="submit" class="button">Safety & Security Badges</button></div>
				
			</div>
			
		</div>
		
		<p>Need help Contact us directly</p>
		<p>Call Customer services at XXX XXX XXXX. Monday -Friday 8.00am - 5.00pm</p>
		<p>Email Customer Services at <a href="#">helpme@domain.com</a></p>
		
		
		
	</div>
	
	<!--END-->
	
	
	
	
	
	<!--Footer Wrapper-->
	<div class="footerbg">
		<div class="footerwrapper">
			<div class="group clearboth">
				<div class="footercol1">
					<h6>Quick Links</h6>
					<a href="blog.php">Blog</a>
					<a href="our-story.php">OUR STORY</a>
					<a href="">ETERNALLY PURE</a>
					<a href="">PROCESS</a>
					<a href="">OUR PILLARS</a>
					<a href="">RECIPES</a>
					<a href="">FAQs</a>
				</div>
				<div class="footercol1">
					<h6>PRODUCTS</h6>
					<a href="products.php">SEED</a>
					<a href="products.php">NUT</a>
					<a href="products.php">COMBOS</a>
					<a href="products.php">SPECIAL PACKS</a>
				</div>
				<div class="footercol1">
					<h6>LEGAL</h6>
					<a href="">TERMS &amp; CONDITIONS</a>
					<a href="">PAYMENT POLICY</a>
					<a href="">CONTACT US</a>
				</div>
				<div class="footercol2">
					<h6>Subscribe to our Newsletter</h6>
					<div class="group clearboth footersearch">
						<input type="text" placeholder="Your Email ID" ><button>Search</button>
					</div>
					<hr>
					<div class="imgper"><img src="images/payment.svg" alt="" ></div>
				</div>
			</div>
			<hr>
			<div class="group clearboth">
				<div class="footerbottomleft"> 
					Copyright &copy; 2022 Soultatva. All Right Reserved | Developed By <a href="" target="_blank">Jency Software</a>
				</div>
				<div class="footerbottomright">
					<div class="footersocial">
						<a href="https://www.facebook.com/Soultatva" target="_blank"><i class="fab fa-facebook"></i></a>
                        <a href="https://www.linkedin.com/showcase/soul-tatva" target="_blank"><i class="fab fa-linkedin"></i></a>
                        <a href="https://twitter.com/SoulTatva" target="_blank"><i class="fab fa-twitter"></i></a>
                        <a href="https://www.instagram.com/soultatva/" target="_blank"><i class="fab fa-instagram"></i></a>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!--END-->
	
	
	
    
 

<script type="text/javascript" src="js/jquery-3.3.1.min.js"></script>
<script type="text/javascript" src="js/ajax-1.9.0.min.js"></script>

<script type="text/javascript">
	$(document).ready(function(){
		$(window).scroll(function(){
			if ($(this).scrollTop() > 50) {
				$('#Arrowfix').fadeIn();
			} else {
				$('#Arrowfix').fadeOut();
			}
		});
		$('#Arrowfix').click(function(){
			$("html, body").animate({ scrollTop: 0 }, 400);
			return false;
		});
	});
</script>
	
<script type="text/javascript">
	var list = $("nav>ul li > a");
	$("nav > a").click(function (event) {
		$("nav>ul").slideToggle();
	});
	list.click(function (event) {
		var submenu = this.parentNode.getElementsByTagName("ul").item(0);
		if (submenu != null) {
			event.preventDefault();
			//$(submenu).slideToggle();
		}
	});
		$(window).resize(function () {
			if ($(window).width() > 1180) {
				$("nav > ul, nav > ul  li  ul").removeAttr("style");
			}
		});
		$(".scroll").click(function (event) { 
			if ($(window).width() < 1180) {
			$("nav>ul").slideToggle();
		}
	 });
</script>	

<script src="js/jquery.balance.js" type="text/javascript"></script>
<script type="text/javascript">
	$(window).load(function() {
		$('.trandingheight').balance() ;
		$('.assetsboxheight').balance() ;
		$('.idxvideoheight').balance() ;
	});
</script>
	
	
<script src="js/jquery.bxslider.js" type="text/javascript"></script>	
<script type="text/javascript">
	
	$(document).ready(function(){
	  if($(window).width() < 30500){
		  $('.headerslider').bxSlider({
			infiniteLoop:true,
			auto:true,
			pager:false,
			controls:true,
			  oneToOneTouch:true,
				pause: 8000,
				touchEnabled: true,
		 });
	  }
	});
	
	$(document).ready(function(){
	  if($(window).width() < 30500){
		  $('.bannerslider').bxSlider({
			infiniteLoop:true,
			auto:true,
			pager:false,
			controls:false,
			  oneToOneTouch:true,
				pause: 8000,
				touchEnabled: true,
		 });
	  }
	});
	
	
	$(document).ready(function(){
		if($(window).width()>1500){
			$('.assetsslide').bxSlider({
				infiniteLoop:true,
				auto:false,
				slideWidth: 370,
				maxSlides: 4,
				pager:false,
				controls:true,
				oneToOneTouch:false,
				pause: 10000,
				touchEnabled: true,
				moveSlides:1,
				 preventDefaultSwipeX:true,
				preventDefaultSwipeY:true
			});
		}
	   
		else{
		if($(window).width()<=1500 && $(window).width() > 1280) {			
			$('.assetsslide').bxSlider({
				slideWidth: 290,
				auto:false,
				maxSlides: 4,
				moveSlides:1,
				pager:false,
				controls:true,
				autoHover: true,
				oneToOneTouch:false,
				pause: 10000,
				touchEnabled: true
			});
		}
		
		else{
		if($(window).width()<=1280 && $(window).width() > 800) {			
			$('.assetsslide').bxSlider({
				slideWidth: 300,
				auto:false,
				maxSlides: 4,
				moveSlides:1,
				pager:false,
				controls:true,
				autoHover: true,
				oneToOneTouch:false,
				pause: 10000,
				touchEnabled: true
			});
		}
		
		else if($(window).width()<=800) {
			$('.assetsslide').bxSlider({
				slideWidth: 400,
				maxSlides: 1
				,pager:false,
				controls:true,
				autoHover: true,
				oneToOneTouch:false,
				pause: 10000,
				touchEnabled: true
			});
		}	   
	   }
			}
	});
	
</script>
	
<script type="text/javascript">	
	$(document).ready(function () {
		size_li = $("#mylist .productbox1").size();
		x=9;
		$('#mylist .productbox1:lt('+x+')').show();
		$('#loadmore').click(function () {
			x= (x+3 <= size_li) ? x+3 : size_li;
			$('#mylist .productbox1:lt('+x+')').show();
		});
		$('#showless').click(function () {
			x=(x-3<0) ? 3 : x-3;
			$('#mylist .productbox1').not(':lt('+x+')').hide();
		});
	});
</script>
	
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.2/jquery.fancybox.min.js"></script>
<script type="text/javascript">
	
	$(document).ready(function() {
		$("data-fancybox").fancybox();
	});
	$(document).ready(function() {
		$(".fancybox").fancybox();
	});
	
	
	$(document).ready(function(){
	  $(".showsingle").click(function(){
		$("#leftmenu"+$(this).attr('target')).toggle();
	  });
	});
	
	
	
	
	
</script>
	
<script type="text/javascript">
	$(window).load(function() {
		$(".loader").fadeOut("slow");
	})
</script>	

</body>
</html>
