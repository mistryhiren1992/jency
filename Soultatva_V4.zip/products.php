<html lang="en">
<head>
<title>Buy Organic Seeds, Dry Fruits &amp; Nuts from Soultatva</title>

<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0, minimal-ui" />


<link rel="icon" type="image/png" href="favicon.png">
<link rel="shortcut icon" href="favicon.ico">


<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Nunito:ital,wght@0,200;0,300;0,400;0,600;0,700;0,800;0,900;1,200;1,300;1,400;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">



<link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">



<link href="css/jquery.bxslider.css" rel="stylesheet" type="text/css" />
	
<link href="css/common-text.css" rel="stylesheet" type="text/css" />
<link href="css/common-layout.css" rel="stylesheet" type="text/css" />
<link href="css/menu.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="css/resrponsive.css">
<link rel="stylesheet" href="css/jquery.fancybox.min.css" type="text/css" media="screen" />
<link href="css/jquery.bxslider.css" rel="stylesheet" type="text/css" />


</head>

<body>
	
    
	<div class="loader"><span></span></div>
	
    <a href="javascript:void(0);" id="Arrowfix" style="display: none;"><span></span></a>
    
	
	
	
	<!--TOPMAIN-->
	<div class="topmain">
		<div class="topmainleft">
			<select name="langues" id="langues">
			  <option value="English">English</option>
			  <option value="Hindi">Hindi</option>
			  <option value="Gujarati">Gujarati</option>
			  <option value="Marathi">Marathi</option>
			</select>
		</div>
		<div class="topmainright">
			<a href="mywhishlist.php">My Wishlist</a> <span>|</span>
			<a href="signin.php">Sign in</a> <span>|</span>
			<a href="register.php">Register</a> <span>|</span>
			<a href="store.php">Store Locator</a> <span>|</span>
			<a href="blog.php">Blog</a>
		</div>
	</div>
	<!--TOPMAIN-->
    
	
	
	<!--TOPMAIN Wrapper-->
	<div class="topmainwrapper">
		<div class="topmaincol1"><a href="index.php"><img src="images/soultatva-logo1.png" alt="" ></a></div>
		<div class="topmaincol2">
			<input type="text" placeholder="Search for products" ><button>Search</button>
		</div>
		<div class="topmaincol3">
			<div class="group clearboth">
				<h6><a href="tel:Call 1300 000 XXX">Call 1300 000 XXX</a></h6>
				<h5><a href="checkout.php">Cart <i class="fa fa-shopping-cart" aria-hidden="true"></i> <span>0</span></a></h5>
			</div>
		</div>
	</div>
	<!--TOPMAIN-->
	
	
	<!--Menu-->
	
	<div class="menubg">
		<nav>
			<a href="#"><i class="fa fa-bars fa-2x"></i></a>
			<ul>
				<li><a href="index.php">Home</a></li>
				<li><a href="about.php">About US</a> <i class="fa fa-caret-down"></i>
					<ul>
						<li><a href="our-story.php">Our Story</a></li>
						<li><a href="eternallypure.php">Eternally Pure</a></li>
						<li><a href="process.php">process</a></li>
					</ul>
				</li>
				<li><a href="products.php">Products</a> <i class="fa fa-caret-down"></i>
					<ul>
						<li><a href="products.php">Products</a></li>
						<li><a href="seed.php">Seed <i class="fa fa-caret-right"></i></a>
							<ul>
								<li><a href="products.php">Seed Name 1</a></li>
								<li><a href="products.php">Seed Name 2</a></li>
								<li><a href="products.php">Seed Name 3</a></li>
							</ul>
						</li>
						<li><a href="nut.php">Nut <i class="fa fa-caret-right"></i></a>
							<ul>
								<li><a href="products.php">Nut Name 1</a></li>
								<li><a href="products.php">Nut Name 2</a></li>
								<li><a href="products.php">Nut Name 3</a></li>
							</ul>
						</li>
						<li><a href="combos.php">Combos <i class="fa fa-caret-right"></i></a>
							<ul>
								<li><a href="products.php">Combos Name 1</a></li>
								<li><a href="products.php">Combos Name 2</a></li>
								<li><a href="products.php">Combos Name 3</a></li>
							</ul>
						</li>
					</ul>
				</li>
				<li><a href="our-pillars.php">Our Pillars</a></li>
				<li><a href="recipes">Recipes</a></li>
				<li><a href="blog.php">Blog</a></li>
				<li><a href="contact-us.php">Contact us</a></li>
			</ul>
		</nav>
	</div>
	
	<!--END-->
	
	
	<!--Contain Wrapper-->
	
	<div class="containwrapper">
		
		<div class="bredcum">
			<h1>Products</h1>
			<a href="index.php">Home</a> <i class="fa fa-angle-double-right"></i> <span>Products</span>
		</div>
		
		<div class="group clearboth">
			<div class="productboxleft">
				
				<div class="productboxmenu">
					<h4 class="showsingle" target="1">Seed <i class="fa fa-chevron-down"></i></h4>
					<div id="leftmenu1" class="group clearboth">
						<a href="#">Raw Chia</a>
						<a href="#">Nutri Mukhwas</a>
						<a href="#">Flax Seeds</a>
						<a href="#">Pumpkin Seeds</a>
						<a href="#">Sunflower Seeds Roasted</a>
						<a href="#">Seeds Trail Mix</a>
					</div>
				</div>
				
				<hr>
				
				<div class="productboxmenu">
					<h4 class="showsingle" target="2">Combos <i class="fa fa-chevron-down"></i></h4>
					<div id="leftmenu2" class="group clearboth">
						<a href="#">Raw Chia</a>
						<a href="#">Nutri Mukhwas</a>
						<a href="#">Flax Seeds</a>
						<a href="#">Pumpkin Seeds</a>
						<a href="#">Sunflower Seeds Roasted</a>
						<a href="#">Seeds Trail Mix</a>
					</div>
				</div>
				
				<hr>
				
				<div class="productboxmenu">
					<h4 class="showsingle" target="3">Nut <i class="fa fa-chevron-down"></i></h4>
					<div id="leftmenu3" class="group clearboth">
						<a href="#">Raw Chia</a>
						<a href="#">Nutri Mukhwas</a>
						<a href="#">Flax Seeds</a>
						<a href="#">Pumpkin Seeds</a>
						<a href="#">Sunflower Seeds Roasted</a>
						<a href="#">Seeds Trail Mix</a>
					</div>
				</div>
				
			</div>
				
				
			
			<div class="productboxright">
				
				<div class="group clearboth" id="mylist">
					
					<div class="conbox2 productbox1">
						<a href="products-detail.php">
							<img src="images/tranding1.jpg" alt="" >
						</a>
						<div class="conbox2con trandingheight">
							<h6>Sunflower Seeds Roasted Salted</h6>
							<h5><span>₹420</span><i>₹599</i></h5>
							<div class="btn1"><a href="products-detail.php">Add to cart</a></div>
						</div>
					</div>
					<div class="conbox2 productbox1">
						<a href="products-detail.php">
							<img src="images/tranding1.jpg" alt="" >
						</a>
						<div class="conbox2con trandingheight">
							<h6>Sunflower Seeds Roasted Salted</h6>
							<h5><span>₹420</span><i>₹599</i></h5>
							<div class="btn1"><a href="products-detail.php">Add to cart</a></div>
						</div>
					</div>
					<div class="conbox2 productbox1">
						<a href="products-detail.php">
							<img src="images/tranding1.jpg" alt="" >
						</a>
						<div class="conbox2con trandingheight">
							<h6>Sunflower Seeds Roasted Salted</h6>
							<h5><span>₹420</span><i>₹599</i></h5>
							<div class="btn1"><a href="products-detail.php">Add to cart</a></div>
						</div>
					</div>
					<div class="conbox2 productbox1">
						<a href="products-detail.php">
							<img src="images/tranding1.jpg" alt="" >
						</a>
						<div class="conbox2con trandingheight">
							<h6>Sunflower Seeds Roasted Salted</h6>
							<h5><span>₹420</span><i>₹599</i></h5>
							<div class="btn1"><a href="products-detail.php">Add to cart</a></div>
						</div>
					</div>
					<div class="conbox2 productbox1">
						<a href="products-detail.php">
							<img src="images/tranding1.jpg" alt="" >
						</a>
						<div class="conbox2con trandingheight">
							<h6>Sunflower Seeds Roasted Salted</h6>
							<h5><span>₹420</span><i>₹599</i></h5>
							<div class="btn1"><a href="products-detail.php">Add to cart</a></div>
						</div>
					</div>
					<div class="conbox2 productbox1">
						<a href="products-detail.php">
							<img src="images/tranding1.jpg" alt="" >
						</a>
						<div class="conbox2con trandingheight">
							<h6>Sunflower Seeds Roasted Salted</h6>
							<h5><span>₹420</span><i>₹599</i></h5>
							<div class="btn1"><a href="products-detail.php">Add to cart</a></div>
						</div>
					</div>
					<div class="conbox2 productbox1">
						<a href="products-detail.php">
							<img src="images/tranding1.jpg" alt="" >
						</a>
						<div class="conbox2con trandingheight">
							<h6>Sunflower Seeds Roasted Salted</h6>
							<h5><span>₹420</span><i>₹599</i></h5>
							<div class="btn1"><a href="products-detail.php">Add to cart</a></div>
						</div>
					</div>
					<div class="conbox2 productbox1">
						<a href="products-detail.php">
							<img src="images/tranding1.jpg" alt="" >
						</a>
						<div class="conbox2con trandingheight">
							<h6>Sunflower Seeds Roasted Salted</h6>
							<h5><span>₹420</span><i>₹599</i></h5>
							<div class="btn1"><a href="products-detail.php">Add to cart</a></div>
						</div>
					</div>
					<div class="conbox2 productbox1">
						<a href="products-detail.php">
							<img src="images/tranding1.jpg" alt="" >
						</a>
						<div class="conbox2con trandingheight">
							<h6>Sunflower Seeds Roasted Salted</h6>
							<h5><span>₹420</span><i>₹599</i></h5>
							<div class="btn1"><a href="products-detail.php">Add to cart</a></div>
						</div>
					</div>
					<div class="conbox2 productbox1">
						<a href="products-detail.php">
							<img src="images/tranding1.jpg" alt="" >
						</a>
						<div class="conbox2con trandingheight">
							<h6>Sunflower Seeds Roasted Salted</h6>
							<h5><span>₹420</span><i>₹599</i></h5>
							<div class="btn1"><a href="products-detail.php">Add to cart</a></div>
						</div>
					</div>
					<div class="conbox2 productbox1">
						<a href="products-detail.php">
							<img src="images/tranding1.jpg" alt="" >
						</a>
						<div class="conbox2con trandingheight">
							<h6>Sunflower Seeds Roasted Salted</h6>
							<h5><span>₹420</span><i>₹599</i></h5>
							<div class="btn1"><a href="products-detail.php">Add to cart</a></div>
						</div>
					</div>
					<div class="conbox2 productbox1">
						<a href="products-detail.php">
							<img src="images/tranding1.jpg" alt="" >
						</a>
						<div class="conbox2con trandingheight">
							<h6>Sunflower Seeds Roasted Salted</h6>
							<h5><span>₹420</span><i>₹599</i></h5>
							<div class="btn1"><a href="products-detail.php">Add to cart</a></div>
						</div>
					</div>
					<div class="conbox2 productbox1">
						<a href="products-detail.php">
							<img src="images/tranding1.jpg" alt="" >
						</a>
						<div class="conbox2con trandingheight">
							<h6>Sunflower Seeds Roasted Salted</h6>
							<h5><span>₹420</span><i>₹599</i></h5>
							<div class="btn1"><a href="products-detail.php">Add to cart</a></div>
						</div>
					</div>
					<div class="conbox2 productbox1">
						<a href="products-detail.php">
							<img src="images/tranding1.jpg" alt="" >
						</a>
						<div class="conbox2con trandingheight">
							<h6>Sunflower Seeds Roasted Salted</h6>
							<h5><span>₹420</span><i>₹599</i></h5>
							<div class="btn1"><a href="products-detail.php">Add to cart</a></div>
						</div>
					</div>
					<div class="conbox2 productbox1">
						<a href="products-detail.php">
							<img src="images/tranding1.jpg" alt="" >
						</a>
						<div class="conbox2con trandingheight">
							<h6>Sunflower Seeds Roasted Salted</h6>
							<h5><span>₹420</span><i>₹599</i></h5>
							<div class="btn1"><a href="products-detail.php">Add to cart</a></div>
						</div>
					</div>
					<div class="conbox2 productbox1">
						<a href="products-detail.php">
							<img src="images/tranding1.jpg" alt="" >
						</a>
						<div class="conbox2con trandingheight">
							<h6>Sunflower Seeds Roasted Salted</h6>
							<h5><span>₹420</span><i>₹599</i></h5>
							<div class="btn1"><a href="products-detail.php">Add to cart</a></div>
						</div>
					</div>
					<div class="conbox2 productbox1">
						<a href="products-detail.php">
							<img src="images/tranding1.jpg" alt="" >
						</a>
						<div class="conbox2con trandingheight">
							<h6>Sunflower Seeds Roasted Salted</h6>
							<h5><span>₹420</span><i>₹599</i></h5>
							<div class="btn1"><a href="products-detail.php">Add to cart</a></div>
						</div>
					</div>
					<div class="conbox2 productbox1">
						<a href="products-detail.php">
							<img src="images/tranding1.jpg" alt="" >
						</a>
						<div class="conbox2con trandingheight">
							<h6>Sunflower Seeds Roasted Salted</h6>
							<h5><span>₹420</span><i>₹599</i></h5>
							<div class="btn1"><a href="products-detail.php">Add to cart</a></div>
						</div>
					</div>
					<div class="conbox2 productbox1">
						<a href="products-detail.php">
							<img src="images/tranding1.jpg" alt="" >
						</a>
						<div class="conbox2con trandingheight">
							<h6>Sunflower Seeds Roasted Salted</h6>
							<h5><span>₹420</span><i>₹599</i></h5>
							<div class="btn1"><a href="products-detail.php">Add to cart</a></div>
						</div>
					</div>
					
					
				</div>
				
				<br>
				<div class="group clearboth"><div class="btn2"><a id="loadmore">Show More</a></div></div>
			
			</div>
		</div>
		
		
		
	</div>
	
	<!--END-->
	
	
	
	
	<!--Contain Wrapper-->
	<div class="bg1">
		<div class="containwrapper footertoptext">
			<h6>Best quality with 100% organic seeds</h6>
			<p>For maintaining a healthy life, you need two things- exercise and a balanced diet. Intake and exposer to GMO and chemical used products give you unhealthy life. These become the reason for illness and unhealthy life. For a healthy life, it’s essential to intake some Organic seeds that boost your energy and immunity power. You must have information about the seed contents and its mother plant when buying seed. The seed grown through organic farming offers a variety of advantages to your health. Soultatva is a leading supplier of organic seeds to their customer. They have a high quality of seed that offers energy and removes illness from the body.</p>

			<h6>Organic Raw chia seeds</h6>
			<p>Though these organic seeds are small but are rich in nutrients, raw chia seeds contain antioxidants, calcium, iron, and Omega-3 fatty acids, excellent nutrient sources. Including the best quality of organic raw chia seeds in your diet helps you fit and fine. These organic seeds can be eaten cooked or by soaking them. Soultatva has high-quality organic seeds that will give your body various benefits. Moreover, organic raw chia seeds are versatile and can be used in many recipes. I embrace their gel-like consistency by mixing them with liquid and making chia pudding.</p>


			<h6>Organic Flaxseeds</h6>
			<p>These Organic seeds are known for their health-protective benefits. Flax seeds are loaded with different nutrients and are the oldest seed found in history. These organic seeds contain Omega-3, protein, fiber, minerals, and vitamins. Those are important nutrients of the body. Flax seeds offer various health benefits to users. Soultatva has a stock of organic seeds loaded with minerals and vitamins.</p>


			<h6>Organic Pumpkin seeds</h6>
			<p>These Organic seeds are known for their good magnesium, fatty acid, antioxidant, and zinc. All of these good sources help your heart in good condition. Pumpkin seeds are also beneficial for controlling blood pressure and cholesterol level, and they both are related to heart disease. Ordering Pumpkin seeds from Soultatva will give you organic seeds of the best quality. Eating only a small amount of them can provide you with a substantial quantity of healthy fats, magnesium, and zinc. Because of this, pumpkin seeds have been associated with several health benefits. These include prostate health and protection against certain cancers. What’s more, one can easily incorporate these seeds into your diet.</p>
			
			<h6>Organic Sunflower Seeds</h6>
			<p>Soultatva’s Sunflower seeds keep the stock of organic sunflower seeds rich in vitamin E, magnesium, calcium, and protein. Using these organic seeds will keep your body active and healthy. Sunflower seeds are harvested from the flower head of the sunflower plant. While the seed itself is encased in a black and white striped shell, sunflower seeds are white and have a tender texture. Known for their distinct nutty flavor and high nutritional value, you can eat the seeds raw, roasted, or incorporated into other dishes.</p>

		</div>
	</div>
	<!--END-->
	
	
	
	
	<!--Footer Wrapper-->
	<div class="footerbg">
		<div class="footerwrapper">
			<div class="group clearboth">
				<div class="footercol1">
					<h6>Quick Links</h6>
					<a href="blog.php">Blog</a>
					<a href="our-story.php">OUR STORY</a>
					<a href="">ETERNALLY PURE</a>
					<a href="">PROCESS</a>
					<a href="">OUR PILLARS</a>
					<a href="">RECIPES</a>
					<a href="">FAQs</a>
				</div>
				<div class="footercol1">
					<h6>PRODUCTS</h6>
					<a href="products.php">SEED</a>
					<a href="products.php">NUT</a>
					<a href="products.php">COMBOS</a>
					<a href="products.php">SPECIAL PACKS</a>
				</div>
				<div class="footercol1">
					<h6>LEGAL</h6>
					<a href="">TERMS &amp; CONDITIONS</a>
					<a href="">PAYMENT POLICY</a>
					<a href="">CONTACT US</a>
				</div>
				<div class="footercol2">
					<h6>Subscribe to our Newsletter</h6>
					<div class="group clearboth footersearch">
						<input type="text" placeholder="Your Email ID" ><button>Search</button>
					</div>
					<hr>
					<div class="imgper"><img src="images/payment.svg" alt="" ></div>
				</div>
			</div>
			<hr>
			<div class="group clearboth">
				<div class="footerbottomleft"> 
					Copyright &copy; 2022 Soultatva. All Right Reserved | Developed By <a href="" target="_blank">Jency Software</a>
				</div>
				<div class="footerbottomright">
					<div class="footersocial">
						<a href="https://www.facebook.com/Soultatva" target="_blank"><i class="fab fa-facebook"></i></a>
                        <a href="https://www.linkedin.com/showcase/soul-tatva" target="_blank"><i class="fab fa-linkedin"></i></a>
                        <a href="https://twitter.com/SoulTatva" target="_blank"><i class="fab fa-twitter"></i></a>
                        <a href="https://www.instagram.com/soultatva/" target="_blank"><i class="fab fa-instagram"></i></a>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!--END-->
	
	
	
    
 

<script type="text/javascript" src="js/jquery-3.3.1.min.js"></script>
<script type="text/javascript" src="js/ajax-1.9.0.min.js"></script>

<script type="text/javascript">
	$(document).ready(function(){
		$(window).scroll(function(){
			if ($(this).scrollTop() > 50) {
				$('#Arrowfix').fadeIn();
			} else {
				$('#Arrowfix').fadeOut();
			}
		});
		$('#Arrowfix').click(function(){
			$("html, body").animate({ scrollTop: 0 }, 400);
			return false;
		});
	});
</script>
	
<script type="text/javascript">
	var list = $("nav>ul li > a");
	$("nav > a").click(function (event) {
		$("nav>ul").slideToggle();
	});
	list.click(function (event) {
		var submenu = this.parentNode.getElementsByTagName("ul").item(0);
		if (submenu != null) {
			event.preventDefault();
			//$(submenu).slideToggle();
		}
	});
		$(window).resize(function () {
			if ($(window).width() > 1180) {
				$("nav > ul, nav > ul  li  ul").removeAttr("style");
			}
		});
		$(".scroll").click(function (event) { 
			if ($(window).width() < 1180) {
			$("nav>ul").slideToggle();
		}
	 });
</script>	

<script src="js/jquery.balance.js" type="text/javascript"></script>
<script type="text/javascript">
	$(window).load(function() {
		$('.trandingheight').balance() ;
		$('.assetsboxheight').balance() ;
		$('.idxvideoheight').balance() ;
	});
</script>
	
	
<script src="js/jquery.bxslider.js" type="text/javascript"></script>	
<script type="text/javascript">
	
	$(document).ready(function(){
	  if($(window).width() < 30500){
		  $('.headerslider').bxSlider({
			infiniteLoop:true,
			auto:true,
			pager:false,
			controls:true,
			  oneToOneTouch:true,
				pause: 8000,
				touchEnabled: true,
		 });
	  }
	});
	
	$(document).ready(function(){
	  if($(window).width() < 30500){
		  $('.bannerslider').bxSlider({
			infiniteLoop:true,
			auto:true,
			pager:false,
			controls:false,
			  oneToOneTouch:true,
				pause: 8000,
				touchEnabled: true,
		 });
	  }
	});
	
	
	$(document).ready(function(){
		if($(window).width()>1500){
			$('.assetsslide').bxSlider({
				infiniteLoop:true,
				auto:false,
				slideWidth: 370,
				maxSlides: 4,
				pager:false,
				controls:true,
				oneToOneTouch:false,
				pause: 10000,
				touchEnabled: true,
				moveSlides:1,
				 preventDefaultSwipeX:true,
				preventDefaultSwipeY:true
			});
		}
	   
		else{
		if($(window).width()<=1500 && $(window).width() > 1280) {			
			$('.assetsslide').bxSlider({
				slideWidth: 290,
				auto:false,
				maxSlides: 4,
				moveSlides:1,
				pager:false,
				controls:true,
				autoHover: true,
				oneToOneTouch:false,
				pause: 10000,
				touchEnabled: true
			});
		}
		
		else{
		if($(window).width()<=1280 && $(window).width() > 800) {			
			$('.assetsslide').bxSlider({
				slideWidth: 300,
				auto:false,
				maxSlides: 4,
				moveSlides:1,
				pager:false,
				controls:true,
				autoHover: true,
				oneToOneTouch:false,
				pause: 10000,
				touchEnabled: true
			});
		}
		
		else if($(window).width()<=800) {
			$('.assetsslide').bxSlider({
				slideWidth: 400,
				maxSlides: 1
				,pager:false,
				controls:true,
				autoHover: true,
				oneToOneTouch:false,
				pause: 10000,
				touchEnabled: true
			});
		}	   
	   }
			}
	});
	
</script>
	
<script type="text/javascript">	
	$(document).ready(function () {
		size_li = $("#mylist .productbox1").size();
		x=9;
		$('#mylist .productbox1:lt('+x+')').show();
		$('#loadmore').click(function () {
			x= (x+3 <= size_li) ? x+3 : size_li;
			$('#mylist .productbox1:lt('+x+')').show();
		});
		$('#showless').click(function () {
			x=(x-3<0) ? 3 : x-3;
			$('#mylist .productbox1').not(':lt('+x+')').hide();
		});
	});
</script>
	
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.2/jquery.fancybox.min.js"></script>
<script type="text/javascript">
	
	$(document).ready(function() {
		$("data-fancybox").fancybox();
	});
	$(document).ready(function() {
		$(".fancybox").fancybox();
	});
	
	
	$(document).ready(function(){
	  $(".showsingle").click(function(){
		$("#leftmenu"+$(this).attr('target')).toggle();
	  });
	});
	
	
	
	
	
</script>
	
<script type="text/javascript">
	$(window).load(function() {
		$(".loader").fadeOut("slow");
	})
</script>	

</body>
</html>
